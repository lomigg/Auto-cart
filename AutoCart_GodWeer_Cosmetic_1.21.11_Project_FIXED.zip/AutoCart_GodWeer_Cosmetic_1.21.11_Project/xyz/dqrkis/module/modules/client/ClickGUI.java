package xyz.dqrkis.module.modules.client;

import net.minecraft.class_3944;
import net.minecraft.class_490;
import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.event.events.PacketReceiveListener;
import xyz.dqrkis.gui.ClickGui;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.module.setting.Setting;
import xyz.dqrkis.utils.EncryptedString;

public final class ClickGUI extends Module implements PacketReceiveListener {
   public static final NumberSetting red = new NumberSetting(EncryptedString.of("Red"), (double)0.0F, (double)255.0F, (double)255.0F, (double)1.0F);
   public static final NumberSetting green = new NumberSetting(EncryptedString.of("Green"), (double)0.0F, (double)255.0F, (double)0.0F, (double)1.0F);
   public static final NumberSetting blue = new NumberSetting(EncryptedString.of("Blue"), (double)0.0F, (double)255.0F, (double)50.0F, (double)1.0F);
   public static final NumberSetting alphaWindow = new NumberSetting(EncryptedString.of("Window Alpha"), (double)0.0F, (double)255.0F, (double)170.0F, (double)1.0F);
   public static final BooleanSetting breathing = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Breathing"), true)).setDescription(EncryptedString.of("phucnguyen_"));
   public static final BooleanSetting rainbow = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Rainbow"), true)).setDescription(EncryptedString.of("phucnguyen_"));
   public static final BooleanSetting background = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Background"), false)).setDescription(EncryptedString.of("Renders the background of the Click Gui"));
   public static final BooleanSetting customFont = new BooleanSetting(EncryptedString.of("Custom Font"), true);
   private final BooleanSetting preventClose = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Prevent Close"), true)).setDescription(EncryptedString.of("Dung Co Bat Len Vai Sever Crash"));
   public static final NumberSetting roundQuads = new NumberSetting(EncryptedString.of("Roundness"), (double)1.0F, (double)10.0F, (double)5.0F, (double)1.0F);
   public static final ModeSetting<AnimationMode> animationMode;
   public static final BooleanSetting antiAliasing;

   public ClickGUI() {
      super(EncryptedString.of("Phuc Nguyen "), EncryptedString.of("Setting "), 344, Category.CLIENT);
      this.addSettings(new Setting[]{red, green, blue, alphaWindow, breathing, rainbow, background, this.preventClose, roundQuads, animationMode, antiAliasing});
   }

   public void onEnable() {
      this.eventManager.add(PacketReceiveListener.class, this);
      Dqrkis.INSTANCE.previousScreen = this.mc.field_1755;
      if (Dqrkis.INSTANCE.clickGui != null) {
         this.mc.method_29970(Dqrkis.INSTANCE.clickGui);
      } else if (this.mc.field_1755 instanceof class_490) {
         Dqrkis.INSTANCE.guiInitialized = true;
      }

      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(PacketReceiveListener.class, this);
      if (this.mc.field_1755 instanceof ClickGui) {
         Dqrkis.INSTANCE.clickGui.method_25419();
         this.mc.method_29970(Dqrkis.INSTANCE.previousScreen);
         Dqrkis.INSTANCE.clickGui.onGuiClose();
      } else if (this.mc.field_1755 instanceof class_490) {
         Dqrkis.INSTANCE.guiInitialized = false;
      }

      super.onDisable();
   }

   public void onPacketReceive(PacketReceiveListener.PacketReceiveEvent event) {
      if (Dqrkis.INSTANCE.guiInitialized && event.packet instanceof class_3944 && this.preventClose.getValue()) {
         event.cancel();
      }

   }

   static {
      animationMode = new ModeSetting<AnimationMode>(EncryptedString.of("Animations"), ClickGUI.AnimationMode.Normal, AnimationMode.class);
      antiAliasing = (BooleanSetting)(new BooleanSetting(EncryptedString.of("MSAA"), true)).setDescription(EncryptedString.of("phucnguyen_"));
   }

   public static enum AnimationMode {
      Normal,
      Positive,
      Off;

      // $FF: synthetic method
      private static AnimationMode[] $values() {
         return new AnimationMode[]{Normal, Positive, Off};
      }
   }
}
