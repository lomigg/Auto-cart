AutoCart 1.21.11 source

Changes in this source package:
- Replaced the previous Dqrkis multi-window GUI with a glass-style AutoCart settings GUI based on the supplied GodWeer GUI design.
- Renamed the ClickGUI module from "Phuc Nguyen" to "Mod Settings".
- Renamed "Xbow Cart" to "Auto Cart bow".
- Removed the GodWeer-derived CatEars cosmetic and its renderer mixin.
- No GodWeer gameplay modules, event bus, renderer, or feature library is included.
- AutoCart modules and their original settings remain in the source.
