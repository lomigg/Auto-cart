# AutoCart — Minecraft 1.21.11

This is a source-only Fabric/Loom project.

The GUI was rebuilt in a glass style based on the supplied GodWeer GUI source, but it is implemented entirely with the AutoCart/Dqrkis module system. GodWeer gameplay features are not included.
