package xyz.dqrkis.gui;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.ColorSetting;
import xyz.dqrkis.module.setting.ItemSetting;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.module.setting.MinMaxSetting;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.module.setting.Setting;
import xyz.dqrkis.module.setting.StringSetting;
import xyz.dqrkis.module.modules.client.ClickGUI;
import xyz.dqrkis.utils.RenderUtils;
import xyz.dqrkis.utils.TextRenderer;

/**
 * Glass-style Click GUI inspired by the supplied GodWeer GUI source.
 *
 * This implementation intentionally uses only AutoCart/Dqrkis classes. No
 * GodWeer modules, event bus, renderer, or gameplay features are imported.
 */
public final class ClickGui extends class_437 {
    public static final int WIDTH = 550;
    public static final int HEIGHT = 310;

    private static final Color PANEL = new Color(10, 11, 17, 235);
    private static final Color PANEL_2 = new Color(18, 20, 28, 245);
    private static final Color CARD = new Color(25, 27, 36, 220);
    private static final Color CARD_HOVER = new Color(35, 38, 50, 235);
    private static final Color WHITE_SOFT = new Color(232, 234, 242);
    private static final Color MUTED = new Color(125, 130, 142);
    private static final Color ACCENT = new Color(204, 82, 255);
    private static final Color ACCENT_2 = new Color(244, 74, 208);

    private int x;
    private int y;
    private boolean dragging;
    private int dragX;
    private int dragY;
    private float scroll;
    private Category selectedCategory = Category.CART;
    private final Set<Module> expandedModules = new HashSet<>();
    private final List<ModuleLayout> layouts = new ArrayList<>();
    private KeybindSetting listeningKeybind;

    public ClickGui() {
        super(class_2561.method_43473());
    }

    @Override
    protected void method_25426() {
        center();
    }

    private void center() {
        this.x = Math.max(8, (this.field_22789 - WIDTH) / 2);
        this.y = Math.max(8, (this.field_22790 - HEIGHT) / 2);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        if (Dqrkis.mc.field_1755 != this) return;

        if (Dqrkis.INSTANCE.previousScreen != null) {
            Dqrkis.INSTANCE.previousScreen.method_25394(context, 0, 0, delta);
        }

        // Dark glass overlay.
        context.method_25294(0, 0, this.field_22789, this.field_22790, new Color(0, 0, 0, 85).getRGB());

        RenderUtils.renderRoundedQuad(context, PANEL, x, y, x + WIDTH, y + HEIGHT, 12, 12, 12, 12, 40);
        RenderUtils.renderRoundedQuad(context, PANEL_2, x + 3, y + 3, x + WIDTH - 3, y + HEIGHT - 3, 10, 10, 10, 10, 40);

        renderSidebar(context, mouseX, mouseY);
        renderHeader(context, mouseX, mouseY);
        renderModules(context, mouseX, mouseY);
        renderFooter(context);
    }

    private void renderSidebar(class_332 context, int mouseX, int mouseY) {
        int sidebarW = 72;
        RenderUtils.renderRoundedQuad(context, new Color(7, 8, 13, 225), x + 4, y + 4, x + sidebarW, y + HEIGHT - 4, 9, 9, 9, 9, 35);

        TextRenderer.drawString("AC", context, x + 22, y + 19, Color.WHITE.getRGB());
        TextRenderer.drawString("AutoCart", context, x + 11, y + 37, MUTED.getRGB());

        Category[] cats = Category.values();
        int cy = y + 67;
        for (Category cat : cats) {
            boolean selected = selectedCategory == cat;
            boolean hovered = mouseX >= x + 9 && mouseX <= x + sidebarW - 7 && mouseY >= cy - 4 && mouseY <= cy + 24;
            Color bg = selected ? new Color(190, 70, 235, 80) : (hovered ? new Color(255, 255, 255, 10) : new Color(0, 0, 0, 0));
            if (bg.getAlpha() > 0) {
                RenderUtils.renderRoundedQuad(context, bg, x + 9, cy - 4, x + sidebarW - 7, cy + 24, 7, 7, 7, 7, 30);
            }
            context.method_25294(x + 9, cy + 3, x + 12, cy + 17, selected ? ACCENT.getRGB() : new Color(70, 72, 82).getRGB());
            TextRenderer.drawString(cat.name, context, x + 17, cy + 8, selected ? Color.WHITE.getRGB() : MUTED.getRGB());
            cy += 32;
        }
    }

    private void renderHeader(class_332 context, int mouseX, int mouseY) {
        int left = x + 84;
        int right = x + WIDTH - 12;
        TextRenderer.drawLargeString("Mod Settings", context, left, y + 20, WHITE_SOFT.getRGB());
        TextRenderer.drawString(selectedCategory.name, context, left, y + 41, MUTED.getRGB());

        // Search field is visual-only; all modules in the selected AutoCart category are shown.
        RenderUtils.renderRoundedQuad(context, new Color(7, 8, 13, 190), right - 116, y + 17, right, y + 39, 8, 8, 8, 8, 30);
        TextRenderer.drawString("Search", context, right - 98, y + 25, new Color(105, 108, 118).getRGB());
    }

    private void renderModules(class_332 context, int mouseX, int mouseY) {
        layouts.clear();
        List<Module> modules = Dqrkis.INSTANCE.getModuleManager().getModulesInCategory(selectedCategory);

        int contentX = x + 84;
        int contentY = y + 54;
        int contentW = WIDTH - 96;
        int contentH = HEIGHT - 82;
        int gap = 6;
        int cols = 2;
        int cardW = (contentW - gap) / cols;
        int headerH = 30;

        float[] colY = {contentY - scroll, contentY - scroll};
        RenderUtils.setScissorRegion(contentX, contentY, contentX + contentW, contentY + contentH);
        for (Module module : modules) {
            boolean expanded = expandedModules.contains(module);
            int settingsH = expanded ? module.getSettings().size() * 23 + 5 : 0;
            int cardH = headerH + settingsH;
            int col = layouts.size() % cols;
            int cardX = contentX + col * (cardW + gap);
            int cardY = (int) colY[col];

            ModuleLayout layout = new ModuleLayout(module, cardX, cardY, cardW, cardH, headerH);
            layouts.add(layout);

            if (cardY + cardH >= contentY && cardY <= contentY + contentH) {
                boolean hovered = mouseX >= cardX && mouseX <= cardX + cardW && mouseY >= cardY && mouseY <= cardY + cardH;
                Color cardBg = hovered ? CARD_HOVER : CARD;
                RenderUtils.renderRoundedQuad(context, cardBg, cardX, cardY, cardX + cardW, cardY + cardH, 7, 7, 7, 7, 30);

                if (module.isEnabled()) {
                    RenderUtils.renderRoundedQuad(context, new Color(206, 73, 241, 120), cardX, cardY, cardX + 3, cardY + cardH, 2, 2, 2, 2, 20);
                }

                TextRenderer.drawString(module.getName(), context, cardX + 8, cardY + 11, module.isEnabled() ? Color.WHITE.getRGB() : WHITE_SOFT.getRGB());
                String bind = getModuleBind(module);
                if (!bind.isEmpty()) {
                    int bw = TextRenderer.getWidth(bind) + 8;
                    RenderUtils.renderRoundedQuad(context, new Color(0, 0, 0, 90), cardX + cardW - bw - 27, cardY + 7, cardX + cardW - 23, cardY + 23, 5, 5, 5, 5, 20);
                    TextRenderer.drawString(bind, context, cardX + cardW - bw - 23, cardY + 11, MUTED.getRGB());
                }

                // Compact GodWeer-style toggle.
                int tx = cardX + cardW - 19;
                int ty = cardY + 10;
                RenderUtils.renderRoundedQuad(context, new Color(48, 50, 60, 210), tx, ty, tx + 15, ty + 9, 5, 5, 5, 5, 20);
                RenderUtils.renderCircle(context, module.isEnabled() ? ACCENT_2 : new Color(105, 108, 118), tx + (module.isEnabled() ? 11 : 4), ty + 4.5, 3.5, 12);

                if (expanded) {
                    int sy = cardY + headerH;
                    for (Setting<?> setting : module.getSettings()) {
                        renderSetting(context, setting, cardX + 7, sy, cardW - 14, mouseX, mouseY);
                        sy += 23;
                    }
                }
            }

            colY[col] += cardH + gap;
        }

        float maxY = Math.max(colY[0], colY[1]);
        float maxScroll = Math.max(0, maxY - (contentY + contentH));
        if (scroll > maxScroll) scroll = maxScroll;
        if (scroll < 0) scroll = 0;

        org.lwjgl.opengl.GL11.glDisable(org.lwjgl.opengl.GL11.GL_SCISSOR_TEST);
    }

    private void renderSetting(class_332 context, Setting<?> setting, int sx, int sy, int sw, int mouseX, int mouseY) {
        RenderUtils.renderRoundedQuad(context, new Color(7, 8, 13, 150), sx, sy + 1, sx + sw, sy + 21, 5, 5, 5, 5, 20);
        String name = setting.getName() == null ? "Setting" : setting.getName().toString();
        TextRenderer.drawString(name, context, sx + 6, sy + 8, new Color(175, 178, 188).getRGB());

        String value = getSettingValue(setting);
        int valueWidth = TextRenderer.getWidth(value);
        TextRenderer.drawString(value, context, sx + sw - valueWidth - 7, sy + 8, getSettingColor(setting));

        if (setting instanceof NumberSetting ns) {
            float pct = (float)((ns.getValue() - ns.getMin()) / Math.max(0.0001, ns.getMax() - ns.getMin()));
            int barX = sx + 6;
            int barY = sy + 19;
            int barW = sw - 12;
            context.method_25294(barX, barY, barX + barW, barY + 2, new Color(45, 47, 56).getRGB());
            context.method_25294(barX, barY, barX + (int)(barW * Math.max(0, Math.min(1, pct))), barY + 2, ACCENT.getRGB());
        }
    }

    private void renderFooter(class_332 context) {
        TextRenderer.drawString("RMB  Settings", context, x + 86, y + HEIGHT - 18, MUTED.getRGB());
        TextRenderer.drawString("LMB  Toggle", context, x + 174, y + HEIGHT - 18, MUTED.getRGB());
        TextRenderer.drawString("AutoCart", context, x + WIDTH - 78, y + HEIGHT - 18, new Color(100, 103, 115).getRGB());
    }

    private String getModuleBind(Module module) {
        if (module.getKey() < 0) return "";
        return keyName(module.getKey());
    }

    private String getSettingValue(Setting<?> setting) {
        if (setting instanceof BooleanSetting bs) return bs.getValue() ? "ON" : "OFF";
        if (setting instanceof NumberSetting ns) return formatNumber(ns.getValue());
        if (setting instanceof ModeSetting<?> ms) return String.valueOf(ms.getMode());
        if (setting instanceof KeybindSetting ks) return ks.isListening() ? "..." : (ks.getKey() < 0 ? "NONE" : keyName(ks.getKey()));
        if (setting instanceof StringSetting ss) {
            String value = ss.getValue();
            if (value == null) return "NONE";
            return value.length() > 14 ? value.substring(0, 14) + "..." : value;
        }
        if (setting instanceof ItemSetting is) return is.getItem() == null ? "NONE" : is.getItem().toString().replace("minecraft:", "");
        if (setting instanceof ColorSetting cs) return cs.toHex();
        if (setting instanceof MinMaxSetting mm) return formatNumber(mm.getMinValue()) + " - " + formatNumber(mm.getMaxValue());
        return "";
    }

    private int getSettingColor(Setting<?> setting) {
        if (setting instanceof BooleanSetting bs) return (bs.getValue() ? ACCENT_2 : MUTED).getRGB();
        if (setting instanceof NumberSetting) return new Color(222, 178, 255).getRGB();
        if (setting instanceof ModeSetting<?>) return new Color(182, 190, 255).getRGB();
        if (setting instanceof KeybindSetting) return new Color(245, 205, 255).getRGB();
        return MUTED.getRGB();
    }

    private String formatNumber(double value) {
        if (Math.abs(value - Math.rint(value)) < 0.00001) return Integer.toString((int)Math.rint(value));
        return String.format("%.2f", value);
    }

    private String keyName(int key) {
        if (key < 0) return "NONE";
        if (key <= 8) {
            return switch (key) {
                case 0 -> "LMB";
                case 1 -> "RMB";
                case 2 -> "MMB";
                default -> "M" + key;
            };
        }
        String name = GLFW.glfwGetKeyName(key, 0);
        return name == null ? "KEY" + key : name.toUpperCase();
    }

    private ModuleLayout findLayout(double mouseX, double mouseY) {
        for (ModuleLayout layout : layouts) {
            if (mouseX >= layout.x && mouseX <= layout.x + layout.width && mouseY >= layout.y && mouseY <= layout.y + layout.height) {
                return layout;
            }
        }
        return null;
    }

    private Setting<?> findSetting(ModuleLayout layout, double mouseX, double mouseY) {
        if (!expandedModules.contains(layout.module)) return null;
        int sy = layout.y + layout.headerHeight;
        for (Setting<?> setting : layout.module.getSettings()) {
            if (mouseY >= sy && mouseY <= sy + 23 && mouseX >= layout.x && mouseX <= layout.x + layout.width) return setting;
            sy += 23;
        }
        return null;
    }

    private void clickSetting(Setting<?> setting, double mouseX, int rowX, int rowW) {
        if (setting instanceof BooleanSetting bs) {
            bs.toggle();
        } else if (setting instanceof ModeSetting<?> ms) {
            ms.cycle();
        } else if (setting instanceof NumberSetting ns) {
            double pct = Math.max(0, Math.min(1, (mouseX - rowX) / Math.max(1.0, rowW)));
            ns.setValue(ns.getMin() + pct * (ns.getMax() - ns.getMin()));
        } else if (setting instanceof MinMaxSetting mm) {
            double pct = Math.max(0, Math.min(1, (mouseX - rowX) / Math.max(1.0, rowW)));
            double value = mm.getMin() + pct * (mm.getMax() - mm.getMin());
            if (mouseX < rowX + rowW / 2.0) mm.setMinValue(value);
            else mm.setMaxValue(value);
        } else if (setting instanceof KeybindSetting ks) {
            ks.setListening(true);
            listeningKeybind = ks;
        }
    }

    @Override
    public boolean method_25404(class_11908 keyInput) {
        int keyCode = keyInput.comp_4795();
        if (listeningKeybind != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_BACKSPACE || keyCode == GLFW.GLFW_KEY_DELETE) {
                listeningKeybind.setKey(-1);
            } else {
                listeningKeybind.setKey(keyCode);
            }
            if (listeningKeybind.isModuleKey()) {
                Module module = moduleForKeybind(listeningKeybind);
                if (module != null) module.setKey(listeningKeybind.getKey());
            }
            listeningKeybind.setListening(false);
            listeningKeybind = null;
            return true;
        }

        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            this.method_25419();
            return true;
        }

        return super.method_25404(keyInput);
    }

    private Module moduleForKeybind(KeybindSetting keybind) {
        for (Module module : Dqrkis.INSTANCE.getModuleManager().getModules()) {
            for (Setting<?> setting : module.getSettings()) {
                if (setting == keybind) return module;
            }
        }
        return null;
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        int button = click.method_74245();

        if (mouseX >= x + 9 && mouseX <= x + 70 && mouseY >= y + 63 && mouseY <= y + 140) {
            int index = (int)((mouseY - (y + 63)) / 32);
            if (index >= 0 && index < Category.values().length) {
                selectedCategory = Category.values()[index];
                scroll = 0;
                expandedModules.clear();
                return true;
            }
        }

        if (mouseX >= x && mouseX <= x + WIDTH && mouseY >= y && mouseY <= y + 32 && button == 0) {
            dragging = true;
            dragX = (int)mouseX - x;
            dragY = (int)mouseY - y;
            return true;
        }

        ModuleLayout layout = findLayout(mouseX, mouseY);
        if (layout != null) {
            Setting<?> setting = findSetting(layout, mouseX, mouseY);
            if (setting != null && button == 0) {
                clickSetting(setting, mouseX, layout.x + 7, layout.width - 14);
                return true;
            }

            if (button == 0 && mouseY <= layout.y + layout.headerHeight) {
                layout.module.toggle();
                return true;
            }
            if (button == 1 && mouseY <= layout.y + layout.headerHeight && !layout.module.getSettings().isEmpty()) {
                if (!expandedModules.add(layout.module)) expandedModules.remove(layout.module);
                return true;
            }
        }

        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25403(class_11909 click, double deltaX, double deltaY) {
        if (dragging && click.method_74245() == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            this.x = Math.max(4, Math.min(this.field_22789 - WIDTH - 4, (int)click.comp_4798() - dragX));
            this.y = Math.max(4, Math.min(this.field_22790 - HEIGHT - 4, (int)click.comp_4799() - dragY));
            return true;
        }
        return super.method_25403(click, deltaX, deltaY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (mouseX >= x + 80 && mouseX <= x + WIDTH && mouseY >= y + 50 && mouseY <= y + HEIGHT - 25) {
            scroll = Math.max(0, scroll - (float)verticalAmount * 18f);
            return true;
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean method_25406(class_11909 click) {
        if (click.method_74245() == GLFW.GLFW_MOUSE_BUTTON_LEFT) dragging = false;
        return super.method_25406(click);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25419() {
        listeningKeybind = null;
        dragging = false;
        ((ClickGUI)Dqrkis.INSTANCE.getModuleManager().getModule(ClickGUI.class)).setEnabledStatus(false);
        Dqrkis.mc.method_29970(Dqrkis.INSTANCE.previousScreen);
        this.onGuiClose();
    }

    public void onGuiClose() {
        expandedModules.clear();
        layouts.clear();
        listeningKeybind = null;
        dragging = false;
    }

    private static final class ModuleLayout {
        final Module module;
        final int x, y, width, height, headerHeight;

        ModuleLayout(Module module, int x, int y, int width, int height, int headerHeight) {
            this.module = module;
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.headerHeight = headerHeight;
        }
    }
}
