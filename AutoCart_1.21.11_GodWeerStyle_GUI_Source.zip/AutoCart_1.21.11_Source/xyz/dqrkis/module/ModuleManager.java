package xyz.dqrkis.module;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;
import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.event.events.ButtonListener;
import xyz.dqrkis.module.modules.cart.Cart;
import xyz.dqrkis.module.modules.cart.XbowCart;
import xyz.dqrkis.module.modules.client.ClickGUI;
import xyz.dqrkis.module.modules.client.Remove;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.utils.EncryptedString;

public final class ModuleManager implements ButtonListener {
   private final List<Module> modules = new ArrayList();

   public ModuleManager() {
      this.addModules();
      this.addKeybinds();
   }

   public void addModules() {
      this.add(new XbowCart());
      this.add(new Cart());
      this.add(new ClickGUI());
      this.add(new Remove());
   }

   public List<Module> getEnabledModules() {
      return this.modules.stream().filter(Module::isEnabled).toList();
   }

   public List<Module> getModules() {
      return this.modules;
   }

   public void addKeybinds() {
      Dqrkis.INSTANCE.getEventManager().add(ButtonListener.class, this);

      for(Module module : this.modules) {
         module.addSetting((new KeybindSetting(EncryptedString.of("Keybind"), module.getKey(), true)).setDescription(EncryptedString.of("Key")));
      }

   }

   public List<Module> getModulesInCategory(Category category) {
      return this.modules.stream().filter((module) -> module.getCategory() == category).toList();
   }

   public <T extends Module> T getModule(Class<T> moduleClass) {
      Stream var10000 = this.modules.stream();
      Objects.requireNonNull(moduleClass);
      return (T)(var10000.filter(moduleClass::isInstance).findFirst().orElse((Object)null));
   }

   public void add(Module module) {
      this.modules.add(module);
   }

   public void onButtonPress(ButtonListener.ButtonEvent event) {
      if (!Remove.destruct) {
         this.modules.forEach((module) -> {
            if (module.getKey() == event.button && event.action == 1) {
               module.toggle();
            }

         });
      }

   }
}
