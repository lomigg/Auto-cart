package xyz.dqrkis;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import net.minecraft.class_310;
import net.minecraft.class_437;
import xyz.dqrkis.event.EventManager;
import xyz.dqrkis.gui.ClickGui;
import xyz.dqrkis.gui.TabGui;
import xyz.dqrkis.managers.FriendManager;
import xyz.dqrkis.managers.ProfileManager;
import xyz.dqrkis.module.ModuleManager;
import xyz.dqrkis.utils.rotation.RotatorManager;

public final class Dqrkis {
   public RotatorManager rotatorManager;
   public ProfileManager profileManager;
   public ModuleManager moduleManager;
   public EventManager eventManager;
   public FriendManager friendManager;
   public static class_310 mc;
   public String version = " b1.3";
   public static boolean BETA;
   public static Dqrkis INSTANCE;
   public boolean guiInitialized;
   public ClickGui clickGui;
   public TabGui tabGui;
   public class_437 previousScreen = null;
   public long lastModified;
   public File dqrkisJar;

   public Dqrkis() throws InterruptedException, IOException {
      INSTANCE = this;
      this.eventManager = new EventManager();
      this.moduleManager = new ModuleManager();
      this.clickGui = new ClickGui();
      this.tabGui = new TabGui();
      this.rotatorManager = new RotatorManager();
      this.profileManager = new ProfileManager();
      this.friendManager = new FriendManager();
      this.getProfileManager().loadProfile();
      this.setLastModified();
      this.guiInitialized = false;
      mc = class_310.method_1551();
   }

   public ProfileManager getProfileManager() {
      return this.profileManager;
   }

   public ModuleManager getModuleManager() {
      return this.moduleManager;
   }

   public FriendManager getFriendManager() {
      return this.friendManager;
   }

   public EventManager getEventManager() {
      return this.eventManager;
   }

   public ClickGui getClickGui() {
      return this.clickGui;
   }

   public TabGui getTabGui() {
      return this.tabGui;
   }

   public void resetModifiedDate() {
      this.dqrkisJar.setLastModified(this.lastModified);
   }

   public String getVersion() {
      return this.version;
   }

   public void setLastModified() {
      try {
         this.dqrkisJar = new File(Dqrkis.class.getProtectionDomain().getCodeSource().getLocation().toURI());
         this.lastModified = this.dqrkisJar.lastModified();
      } catch (URISyntaxException var2) {
      }

   }
}
