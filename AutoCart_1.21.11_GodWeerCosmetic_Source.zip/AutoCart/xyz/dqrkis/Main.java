package xyz.dqrkis;

import java.io.IOException;
import net.fabricmc.api.ModInitializer;
import xyz.dqrkis.module.modules.cosmetic.CosmeticRenderManager;

public final class Main implements ModInitializer {
   public void onInitialize() {
      try {
         new Dqrkis();
         CosmeticRenderManager.init();
      } catch (IOException | InterruptedException var2) {
      }

   }
}
