package xyz.dqrkis.gui;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.ColorSetting;
import xyz.dqrkis.module.setting.ItemSetting;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.module.setting.MinMaxSetting;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.module.setting.Setting;
import xyz.dqrkis.module.setting.StringSetting;
import xyz.dqrkis.module.modules.client.ClickGUI;
import xyz.dqrkis.utils.RenderUtils;
import xyz.dqrkis.utils.TextRenderer;

/**
 * AutoCart Glass GUI.
 *
 * The layout is a native AutoCart implementation of the supplied GodWeer
 * GlassClickGui/NewGlassGui design: narrow icon/category rail, search bar,
 * module list on the left and a settings panel on the right.  No GodWeer
 * module, event bus, renderer or gameplay code is used.
 */
public final class ClickGui extends class_437 {
    public static final int WIDTH = 550;
    public static final int HEIGHT = 310;

    private static final Color BG = new Color(12, 13, 20, 238);
    private static final Color BG2 = new Color(18, 19, 28, 220);
    private static final Color CARD = new Color(24, 25, 35, 205);
    private static final Color CARD_HOVER = new Color(34, 35, 47, 225);
    private static final Color RAIL = new Color(8, 9, 15, 235);
    private static final Color TEXT = new Color(238, 238, 245);
    private static final Color MUTED = new Color(112, 114, 126);
    private static final Color ACCENT = new Color(204, 82, 255);
    private static final Color ACCENT2 = new Color(242, 78, 211);

    private int x;
    private int y;
    private boolean dragging;
    private int dragX;
    private int dragY;
    private float moduleScroll;
    private float settingScroll;

    private Category selectedCategory = Category.CART;
    private Module selectedModule;
    private KeybindSetting listeningKeybind;
    private final List<ModuleLayout> moduleLayouts = new ArrayList<>();

    public ClickGui() {
        super(class_2561.method_43473());
    }

    @Override
    protected void method_25426() {
        center();
        selectedModule = firstModule(selectedCategory);
    }

    private void center() {
        x = Math.max(5, (field_22789 - WIDTH) / 2);
        y = Math.max(5, (field_22790 - HEIGHT) / 2);
    }

    private Module firstModule(Category category) {
        List<Module> modules = Dqrkis.INSTANCE.getModuleManager().getModulesInCategory(category);
        return modules.isEmpty() ? null : modules.get(0);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        if (Dqrkis.mc.field_1755 != this) return;

        if (Dqrkis.INSTANCE.previousScreen != null) {
            Dqrkis.INSTANCE.previousScreen.method_25394(context, 0, 0, delta);
        }

        context.method_25294(0, 0, field_22789, field_22790, new Color(0, 0, 0, 75).getRGB());
        RenderUtils.renderRoundedQuad(context, BG, x, y, x + WIDTH, y + HEIGHT, 12, 12, 12, 12, 35);
        RenderUtils.renderRoundedQuad(context, BG2, x + 1, y + 1, x + WIDTH - 1, y + HEIGHT - 1, 11, 11, 11, 11, 35);

        renderRail(context, mouseX, mouseY);
        renderTop(context, mouseX, mouseY);
        renderModules(context, mouseX, mouseY);
        renderSettings(context, mouseX, mouseY);
    }

    private void renderRail(class_332 context, int mouseX, int mouseY) {
        RenderUtils.renderRoundedQuad(context, RAIL, x, y, x + 30, y + HEIGHT, 12, 0, 12, 0, 35);

        TextRenderer.drawString("A", context, x + 10, y + 10, ACCENT.getRGB());

        Category[] categories = Category.values();
        int cy = y + 42;
        for (int i = 0; i < categories.length; i++) {
            Category cat = categories[i];
            boolean selected = selectedCategory == cat;
            boolean hovered = mouseX >= x + 3 && mouseX <= x + 27 && mouseY >= cy - 3 && mouseY <= cy + 19;
            if (selected || hovered) {
                RenderUtils.renderRoundedQuad(context, selected ? new Color(204, 82, 255, 55) : new Color(255,255,255,12),
                        x + 4, cy - 2, x + 26, cy + 18, 5, 5, 5, 5, 20);
            }
            String icon = i == 0 ? "C" : "S";
            TextRenderer.drawString(icon, context, x + 11, cy + 4, selected ? ACCENT2.getRGB() : MUTED.getRGB());
            cy += 25;
        }

        boolean client = selectedCategory == Category.CLIENT;
        if (client) {
            TextRenderer.drawString("S", context, x + 11, y + HEIGHT - 26, ACCENT2.getRGB());
        } else {
            TextRenderer.drawString("•", context, x + 12, y + HEIGHT - 26, MUTED.getRGB());
        }
    }

    private void renderTop(class_332 context, int mouseX, int mouseY) {
        int topX = x + 42;
        TextRenderer.drawLargeString(selectedCategory.name, context, topX, y + 9, TEXT.getRGB());
        TextRenderer.drawString("AutoCart", context, topX, y + 28, MUTED.getRGB());

        int searchX = x + 132;
        int searchY = y + 8;
        RenderUtils.renderRoundedQuad(context, new Color(18, 20, 28, 170), searchX, searchY, searchX + 130, searchY + 17, 5, 5, 5, 5, 25);
        TextRenderer.drawString("⌕", context, searchX + 6, searchY + 4, MUTED.getRGB());
        TextRenderer.drawString("Search", context, searchX + 18, searchY + 4, new Color(100, 102, 112).getRGB());

        TextRenderer.drawString("AutoCart", context, x + WIDTH - 68, y + 10, TEXT.getRGB());
        TextRenderer.drawString("Client", context, x + WIDTH - 50, y + 23, MUTED.getRGB());
    }

    private void renderModules(class_332 context, int mouseX, int mouseY) {
        int leftX = x + 42;
        int top = y + 49;
        int listW = 155;
        int bottom = y + HEIGHT - 12;

        TextRenderer.drawString("Modules", context, leftX, top, MUTED.getRGB());
        TextRenderer.drawString("RMB: settings", context, leftX + 76, top, MUTED.getRGB());

        moduleLayouts.clear();
        List<Module> modules = Dqrkis.INSTANCE.getModuleManager().getModulesInCategory(selectedCategory);
        int rowY = top + 17 - (int) moduleScroll;

        RenderUtils.setScissorRegion(leftX, top + 15, leftX + listW, bottom);
        for (Module module : modules) {
            int h = 23;
            ModuleLayout layout = new ModuleLayout(module, leftX, rowY, listW, h);
            moduleLayouts.add(layout);

            if (rowY + h >= top + 15 && rowY <= bottom) {
                boolean hover = mouseX >= leftX && mouseX <= leftX + listW && mouseY >= rowY && mouseY <= rowY + h;
                boolean selected = selectedModule == module;
                Color rowBg = selected ? new Color(204,82,255,45) : (hover ? CARD_HOVER : CARD);
                RenderUtils.renderRoundedQuad(context, rowBg, leftX, rowY, leftX + listW, rowY + h, 7, 7, 7, 7, 25);
                if (module.isEnabled()) {
                    context.method_25294(leftX + 1, rowY + 4, leftX + 3, rowY + h - 4, ACCENT2.getRGB());
                }
                TextRenderer.drawString(module.getName(), context, leftX + 7, rowY + 7, module.isEnabled() ? TEXT.getRGB() : new Color(190,191,201).getRGB());
                String bind = module.getKey() < 0 ? "" : keyName(module.getKey());
                if (!bind.isEmpty()) TextRenderer.drawString(bind, context, leftX + listW - TextRenderer.getWidth(bind) - 7, rowY + 7, MUTED.getRGB());
            }
            rowY += h + 3;
        }
        org.lwjgl.opengl.GL11.glDisable(org.lwjgl.opengl.GL11.GL_SCISSOR_TEST);

        int maxScroll = Math.max(0, modules.size() * 26 - (bottom - (top + 15)));
        moduleScroll = Math.max(0, Math.min(moduleScroll, maxScroll));
    }

    private void renderSettings(class_332 context, int mouseX, int mouseY) {
        int panelX = x + 208;
        int panelY = y + 49;
        int panelW = WIDTH - 220;
        int panelH = HEIGHT - 61;

        RenderUtils.renderRoundedQuad(context, new Color(10, 11, 17, 165), panelX, panelY, panelX + panelW, panelY + panelH, 9, 9, 9, 9, 30);

        if (selectedModule == null) {
            TextRenderer.drawString("Select a module", context, panelX + 10, panelY + 13, MUTED.getRGB());
            return;
        }

        TextRenderer.drawString(selectedModule.getName(), context, panelX + 10, panelY + 10, TEXT.getRGB());
        TextRenderer.drawString(selectedModule.isEnabled() ? "Enabled" : "Disabled", context, panelX + 10, panelY + 25, selectedModule.isEnabled() ? ACCENT2.getRGB() : MUTED.getRGB());

        int rowY = panelY + 42 - (int) settingScroll;
        List<Setting<?>> settings = selectedModule.getSettings();
        RenderUtils.setScissorRegion(panelX, panelY + 38, panelX + panelW, panelY + panelH - 2);
        for (Setting<?> setting : settings) {
            if (rowY + 27 >= panelY + 38 && rowY <= panelY + panelH) renderSetting(context, setting, panelX + 8, rowY, panelW - 16, mouseX, mouseY);
            rowY += 30;
        }
        org.lwjgl.opengl.GL11.glDisable(org.lwjgl.opengl.GL11.GL_SCISSOR_TEST);

        int maxScroll = Math.max(0, settings.size() * 30 - (panelH - 40));
        settingScroll = Math.max(0, Math.min(settingScroll, maxScroll));
    }

    private void renderSetting(class_332 context, Setting<?> setting, int sx, int sy, int sw, int mouseX, int mouseY) {
        boolean hover = mouseX >= sx && mouseX <= sx + sw && mouseY >= sy && mouseY <= sy + 27;
        RenderUtils.renderRoundedQuad(context, hover ? CARD_HOVER : new Color(25,26,36,175), sx, sy, sx + sw, sy + 27, 6, 6, 6, 6, 20);
        String name = setting.getName() == null ? "Setting" : setting.getName().toString();
        TextRenderer.drawString(name, context, sx + 7, sy + 5, new Color(190,191,202).getRGB());
        String value = getSettingValue(setting);
        int vw = TextRenderer.getWidth(value);
        TextRenderer.drawString(value, context, sx + sw - vw - 7, sy + 5, getSettingColor(setting));

        if (setting instanceof NumberSetting ns) {
            double pct = (ns.getValue() - ns.getMin()) / Math.max(0.0001, ns.getMax() - ns.getMin());
            int barY = sy + 23;
            context.method_25294(sx + 7, barY, sx + sw - 7, barY + 2, new Color(50,51,61).getRGB());
            context.method_25294(sx + 7, barY, sx + 7 + (int)((sw - 14) * Math.max(0, Math.min(1, pct))), barY + 2, ACCENT.getRGB());
        }
    }

    private String getSettingValue(Setting<?> setting) {
        if (setting instanceof BooleanSetting bs) return bs.getValue() ? "ON" : "OFF";
        if (setting instanceof NumberSetting ns) return formatNumber(ns.getValue());
        if (setting instanceof ModeSetting<?> ms) return String.valueOf(ms.getMode());
        if (setting instanceof KeybindSetting ks) return ks.isListening() ? "..." : (ks.getKey() < 0 ? "NONE" : keyName(ks.getKey()));
        if (setting instanceof StringSetting ss) { String v = ss.getValue(); return v == null ? "NONE" : (v.length() > 12 ? v.substring(0,12) + "..." : v); }
        if (setting instanceof ItemSetting is) return is.getItem() == null ? "NONE" : is.getItem().toString().replace("minecraft:", "");
        if (setting instanceof ColorSetting cs) return cs.toHex();
        if (setting instanceof MinMaxSetting mm) return formatNumber(mm.getMinValue()) + "-" + formatNumber(mm.getMaxValue());
        return "";
    }

    private int getSettingColor(Setting<?> setting) {
        if (setting instanceof BooleanSetting bs) return (bs.getValue() ? ACCENT2 : MUTED).getRGB();
        if (setting instanceof NumberSetting) return new Color(220,177,255).getRGB();
        if (setting instanceof ModeSetting<?>) return new Color(180,185,255).getRGB();
        if (setting instanceof KeybindSetting) return new Color(245,205,255).getRGB();
        return MUTED.getRGB();
    }

    private void clickSetting(Setting<?> setting, double mouseX, int sx, int sw) {
        if (setting instanceof BooleanSetting bs) bs.toggle();
        else if (setting instanceof ModeSetting<?> ms) ms.cycle();
        else if (setting instanceof NumberSetting ns) {
            double pct = Math.max(0, Math.min(1, (mouseX - sx) / Math.max(1.0, sw)));
            ns.setValue(ns.getMin() + pct * (ns.getMax() - ns.getMin()));
        } else if (setting instanceof MinMaxSetting mm) {
            double pct = Math.max(0, Math.min(1, (mouseX - sx) / Math.max(1.0, sw)));
            double v = mm.getMin() + pct * (mm.getMax() - mm.getMin());
            if (mouseX < sx + sw / 2.0) mm.setMinValue(v); else mm.setMaxValue(v);
        } else if (setting instanceof KeybindSetting ks) {
            ks.setListening(true);
            listeningKeybind = ks;
        }
    }

    @Override
    public boolean method_25404(class_11908 input) {
        int key = input.comp_4795();
        if (listeningKeybind != null) {
            listeningKeybind.setKey(key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE ? -1 : key);
            if (listeningKeybind.isModuleKey()) {
                Module module = moduleForKeybind(listeningKeybind);
                if (module != null) module.setKey(listeningKeybind.getKey());
            }
            listeningKeybind.setListening(false);
            listeningKeybind = null;
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) { method_25419(); return true; }
        return super.method_25404(input);
    }

    private Module moduleForKeybind(KeybindSetting keybind) {
        for (Module module : Dqrkis.INSTANCE.getModuleManager().getModules()) for (Setting<?> setting : module.getSettings()) if (setting == keybind) return module;
        return null;
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        double mx = click.comp_4798();
        double my = click.comp_4799();
        int button = click.method_74245();

        // Category rail: CART / CLIENT.
        int cy = y + 42;
        for (Category cat : Category.values()) {
            if (mx >= x + 3 && mx <= x + 28 && my >= cy - 3 && my <= cy + 20) {
                selectedCategory = cat;
                selectedModule = firstModule(cat);
                moduleScroll = 0;
                settingScroll = 0;
                return true;
            }
            cy += 25;
        }

        // Drag the glass window from its top strip.
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && mx >= x + 30 && mx <= x + WIDTH && my >= y && my <= y + 37) {
            dragging = true;
            dragX = (int)mx - x;
            dragY = (int)my - y;
            return true;
        }

        for (ModuleLayout layout : moduleLayouts) {
            if (mx >= layout.x && mx <= layout.x + layout.w && my >= layout.y && my <= layout.y + layout.h) {
                if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
                    if (my <= layout.y + layout.h) layout.module.toggle();
                    selectedModule = layout.module;
                    settingScroll = 0;
                    return true;
                }
                if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
                    selectedModule = layout.module;
                    settingScroll = 0;
                    return true;
                }
            }
        }

        if (selectedModule != null) {
            int panelX = x + 208, panelY = y + 49, panelW = WIDTH - 220;
            int sy = panelY + 42 - (int)settingScroll;
            for (Setting<?> setting : selectedModule.getSettings()) {
                if (mx >= panelX + 8 && mx <= panelX + panelW - 8 && my >= sy && my <= sy + 27 && button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
                    clickSetting(setting, mx, panelX + 8, panelW - 16);
                    return true;
                }
                sy += 30;
            }
        }
        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25403(class_11909 click, double dx, double dy) {
        if (dragging && click.method_74245() == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            x = Math.max(4, Math.min(field_22789 - WIDTH - 4, (int)click.comp_4798() - dragX));
            y = Math.max(4, Math.min(field_22790 - HEIGHT - 4, (int)click.comp_4799() - dragY));
            return true;
        }
        return super.method_25403(click, dx, dy);
    }

    @Override
    public boolean method_25401(double mx, double my, double horizontal, double vertical) {
        if (mx >= x + 42 && mx <= x + 200 && my >= y + 64 && my <= y + HEIGHT - 10) {
            moduleScroll = Math.max(0, moduleScroll - (float)vertical * 18f);
            return true;
        }
        if (mx >= x + 208 && mx <= x + WIDTH && my >= y + 49 && my <= y + HEIGHT) {
            settingScroll = Math.max(0, settingScroll - (float)vertical * 18f);
            return true;
        }
        return super.method_25401(mx, my, horizontal, vertical);
    }

    @Override
    public boolean method_25406(class_11909 click) {
        if (click.method_74245() == GLFW.GLFW_MOUSE_BUTTON_LEFT) dragging = false;
        return super.method_25406(click);
    }

    @Override
    public boolean method_25421() { return false; }

    @Override
    public void method_25419() {
        listeningKeybind = null;
        dragging = false;
        ((ClickGUI)Dqrkis.INSTANCE.getModuleManager().getModule(ClickGUI.class)).setEnabledStatus(false);
        this.onGuiClose();
    }

    public void onGuiClose() {
        Dqrkis.mc.method_29970(Dqrkis.INSTANCE.previousScreen);
    }

    private String formatNumber(double v) { return Math.abs(v - Math.rint(v)) < 0.00001 ? Integer.toString((int)Math.rint(v)) : String.format("%.2f", v); }

    private String keyName(int key) {
        if (key < 0) return "NONE";
        if (key == GLFW.GLFW_MOUSE_BUTTON_LEFT) return "LMB";
        if (key == GLFW.GLFW_MOUSE_BUTTON_RIGHT) return "RMB";
        String n = GLFW.glfwGetKeyName(key, 0);
        return n == null ? "KEY" + key : n.toUpperCase();
    }

    private static final class ModuleLayout {
        final Module module; final int x, y, w, h;
        ModuleLayout(Module module, int x, int y, int w, int h) { this.module = module; this.x = x; this.y = y; this.w = w; this.h = h; }
    }
}
