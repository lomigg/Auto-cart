package xyz.dqrkis.module;

import xyz.dqrkis.utils.EncryptedString;

public enum Category {
   CART(EncryptedString.of("Cart PvP")),
   CLIENT(EncryptedString.of("Client")),
   COSMETIC(EncryptedString.of("Cosmetic"));

   public final CharSequence name;

   private Category(CharSequence name) {
      this.name = name;
   }
}
