package xyz.dqrkis.module.modules.cosmetic;

import java.awt.Color;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.ColorSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.EncryptedString;

public final class ChinaHat extends Module {
   public final ColorSetting color = new ColorSetting(EncryptedString.of("Color"), new Color(220, 80, 255, 220));
   public final NumberSetting radius = new NumberSetting(EncryptedString.of("Radius"), 0.35, 1.1, 0.7, 0.05);
   public final NumberSetting height = new NumberSetting(EncryptedString.of("Height"), 0.08, 0.55, 0.25, 0.01);

   public ChinaHat() {
      super(EncryptedString.of("China Hat"), EncryptedString.of("GodWeer-style hat cosmetic"), -1, Category.COSMETIC);
      addSettings(color, radius, height);
   }
}
