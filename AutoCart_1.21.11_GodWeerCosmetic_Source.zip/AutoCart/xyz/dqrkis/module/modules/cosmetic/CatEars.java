package xyz.dqrkis.module.modules.cosmetic;

import java.awt.Color;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.ColorSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.EncryptedString;

public final class CatEars extends Module {
   public final ColorSetting outer = new ColorSetting(EncryptedString.of("Outer Color"), new Color(25, 25, 30, 255));
   public final ColorSetting inner = new ColorSetting(EncryptedString.of("Inner Color"), new Color(255, 160, 180, 255));
   public final NumberSetting size = new NumberSetting(EncryptedString.of("Size"), 0.6, 1.6, 1.0, 0.1);

   public CatEars() {
      super(EncryptedString.of("Cat Ears"), EncryptedString.of("GodWeer-style 3D cat ears cosmetic"), -1, Category.COSMETIC);
      addSettings(outer, inner, size);
   }
}
