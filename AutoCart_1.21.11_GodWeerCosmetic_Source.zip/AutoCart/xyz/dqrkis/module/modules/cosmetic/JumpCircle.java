package xyz.dqrkis.module.modules.cosmetic;

import java.awt.Color;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.ColorSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.EncryptedString;

public final class JumpCircle extends Module {
   public final ColorSetting color = new ColorSetting(EncryptedString.of("Color"), new Color(180, 60, 255, 190));
   public final NumberSetting radius = new NumberSetting(EncryptedString.of("Radius"), 0.4, 3.0, 1.4, 0.1);
   public final NumberSetting lifetime = new NumberSetting(EncryptedString.of("Lifetime"), 0.3, 2.5, 1.0, 0.1);
   public JumpCircle() {
      super(EncryptedString.of("Jump Circle"), EncryptedString.of("Cosmetic circle effect when jumping"), -1, Category.COSMETIC);
      addSettings(color, radius, lifetime);
   }
}
