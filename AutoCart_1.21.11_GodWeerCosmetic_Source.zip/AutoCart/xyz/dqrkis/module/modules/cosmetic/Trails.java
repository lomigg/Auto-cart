package xyz.dqrkis.module.modules.cosmetic;

import java.awt.Color;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.ColorSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.EncryptedString;

public final class Trails extends Module {
   public final ColorSetting color = new ColorSetting(EncryptedString.of("Color"), new Color(220, 80, 255, 170));
   public final NumberSetting length = new NumberSetting(EncryptedString.of("Length"), 4, 30, 12, 1);
   public Trails() {
      super(EncryptedString.of("Trails"), EncryptedString.of("Cosmetic movement trail"), -1, Category.COSMETIC);
      addSettings(color, length);
   }
}
