package xyz.dqrkis.module.modules.cosmetic;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.Deque;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.utils.RenderUtils;

/**
 * Small, self-contained cosmetic renderer.  It intentionally contains only
 * visual effects and does not import or depend on the GodWeer client.
 */
public final class CosmeticRenderManager {
   private static final Deque<class_243> trail = new ArrayDeque<>();
   private static long lastTrailSample;
   private static long lastJump;
   private static class_243 jumpPos;

   private CosmeticRenderManager() {}

   public static void init() {
      WorldRenderEvents.AFTER_ENTITIES.register(context -> render(context.matrixStack()));
   }

   private static void render(class_4587 matrices) {
      class_310 mc = Dqrkis.mc;
      if (mc == null || mc.field_1724 == null || mc.field_1687 == null) return;

      class_243 camera = mc.field_1773.method_71156();
      class_243 player = mc.field_1724.method_19538();
      class_243 rel = player.method_1020(camera);

      Module cat = Dqrkis.INSTANCE.getModuleManager().getModule(CatEars.class);
      Module hat = Dqrkis.INSTANCE.getModuleManager().getModule(ChinaHat.class);
      Module wings = Dqrkis.INSTANCE.getModuleManager().getModule(Wings.class);
      Module trails = Dqrkis.INSTANCE.getModuleManager().getModule(Trails.class);
      Module jump = Dqrkis.INSTANCE.getModuleManager().getModule(JumpCircle.class);
      Module model = Dqrkis.INSTANCE.getModuleManager().getModule(CustomModel.class);

      if (trails != null && trails.isEnabled()) sampleTrail(player);
      if (jump != null && jump.isEnabled()) updateJump(player);

      matrices.method_22903();
      matrices.method_22904(rel.field_1352, rel.field_1351, rel.field_1350);

      if (cat instanceof CatEars c && c.isEnabled()) renderCatEars(matrices, c);
      if (hat instanceof ChinaHat h && h.isEnabled()) renderHat(matrices, h);
      if (wings instanceof Wings w && w.isEnabled()) renderWings(matrices, w);
      if (model instanceof CustomModel cm && cm.isEnabled()) renderModel(matrices, cm);
      matrices.method_22909();

      if (trails instanceof Trails t && t.isEnabled()) renderTrail(matrices, camera, t);
      if (jump instanceof JumpCircle j && j.isEnabled()) renderJump(matrices, camera, j);
   }

   private static void sampleTrail(class_243 pos) {
      long now = System.currentTimeMillis();
      if (now - lastTrailSample < 45L) return;
      lastTrailSample = now;
      trail.addLast(pos);
      while (trail.size() > 30) trail.removeFirst();
   }

   private static void renderTrail(class_4587 matrices, class_243 camera, Trails t) {
      int max = Math.min(t.length.getValueInt(), trail.size());
      class_243 previous = null;
      int i = 0;
      for (class_243 p : trail) {
         if (previous != null && i++ >= trail.size() - max) {
            float alpha = Math.max(0.05f, (float)i / Math.max(1, max));
            Color c = withAlpha(t.color.getValue(), (int)(t.color.getValue().getAlpha() * alpha));
            RenderUtils.renderLine(matrices, c, previous.method_1020(camera), p.method_1020(camera));
         }
         previous = p;
      }
   }

   private static void updateJump(class_243 pos) {
      if (Dqrkis.mc.field_1724.method_24828()) return;
      if (Dqrkis.mc.field_1724.method_18798().field_1351 > 0.02 && System.currentTimeMillis() - lastJump > 220L) {
         lastJump = System.currentTimeMillis();
         jumpPos = pos;
      }
   }

   private static void renderJump(class_4587 matrices, class_243 camera, JumpCircle j) {
      if (jumpPos == null) return;
      float progress = (System.currentTimeMillis() - lastJump) / (float)(j.lifetime.getValue() * 1000.0);
      if (progress >= 1.0f) return;
      float radius = (float)(j.radius.getValue() * (0.35 + 0.65 * progress));
      Color c = withAlpha(j.color.getValue(), (int)(j.color.getValue().getAlpha() * (1.0f - progress)));
      class_243 center = jumpPos.method_1020(camera);
      int segments = 48;
      for (int i = 0; i < segments; i++) {
         double a1 = Math.PI * 2.0 * i / segments;
         double a2 = Math.PI * 2.0 * (i + 1) / segments;
         class_243 a = new class_243(center.field_1352 + Math.cos(a1) * radius, center.field_1351, center.field_1350 + Math.sin(a1) * radius);
         class_243 b = new class_243(center.field_1352 + Math.cos(a2) * radius, center.field_1351, center.field_1350 + Math.sin(a2) * radius);
         RenderUtils.renderLine(matrices, c, a, b);
      }
   }

   private static void renderCatEars(class_4587 m, CatEars c) {
      float s = c.size.getValueFloat();
      Color outer = c.outer.getValue();
      Color inner = c.inner.getValue();
      // Head-height approximation: two small layered blocks give the same
      // silhouette without importing GodWeer's renderer/framework.
      m.method_22905(s, s, s);
      RenderUtils.renderFilledBox(m, -0.32f, 1.82f, -0.16f, -0.05f, 2.22f, 0.16f, outer);
      RenderUtils.renderFilledBox(m, 0.05f, 1.82f, -0.16f, 0.32f, 2.22f, 0.16f, outer);
      RenderUtils.renderFilledBox(m, -0.24f, 1.92f, -0.18f, -0.12f, 2.12f, 0.18f, inner);
      RenderUtils.renderFilledBox(m, 0.12f, 1.92f, -0.18f, 0.24f, 2.12f, 0.18f, inner);
   }

   private static void renderHat(class_4587 m, ChinaHat h) {
      Color c = h.color.getValue();
      float r = h.radius.getValueFloat();
      float y = 2.18f;
      float height = h.height.getValueFloat();
      int segments = 48;
      class_243 prev = null;
      for (int i = 0; i <= segments; i++) {
         double a = Math.PI * 2.0 * i / segments;
         class_243 p = new class_243(Math.cos(a) * r, y, Math.sin(a) * r);
         if (prev != null) RenderUtils.renderLine(m, c, prev, p);
         prev = p;
      }
      RenderUtils.renderLine(m, c, new class_243(0, y + height, 0), new class_243(r, y, 0));
      RenderUtils.renderLine(m, c, new class_243(0, y + height, 0), new class_243(-r, y, 0));
      RenderUtils.renderLine(m, c, new class_243(0, y + height, 0), new class_243(0, y, r));
      RenderUtils.renderLine(m, c, new class_243(0, y + height, 0), new class_243(0, y, -r));
   }

   private static void renderWings(class_4587 m, Wings w) {
      Color c = w.color.getValue();
      float s = w.scale.getValueFloat();
      float y = 1.55f;
      drawWing(m, c, -1, s, y);
      drawWing(m, c, 1, s, y);
   }

   private static void drawWing(class_4587 m, Color c, int side, float s, float y) {
      class_243 a = new class_243(0, y, 0);
      class_243 b = new class_243(side * 0.65 * s, y + 0.55 * s, 0.12);
      class_243 d = new class_243(side * 0.95 * s, y - 0.35 * s, 0.05);
      RenderUtils.renderLine(m, c, a, b);
      RenderUtils.renderLine(m, c, b, d);
      RenderUtils.renderLine(m, c, d, a);
   }

   private static void renderModel(class_4587 m, CustomModel cm) {
      float s = cm.scale.getValueFloat();
      Color c = new Color(150, 80, 230, 180);
      m.method_22904(0, 0.45, 0.55);
      RenderUtils.renderFilledBox(m, -0.22f * s, 0.0f, -0.22f * s, 0.22f * s, 0.44f * s, 0.22f * s, c);
   }

   private static Color withAlpha(Color color, int alpha) {
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.max(0, Math.min(255, alpha)));
   }
}
