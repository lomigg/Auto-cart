package xyz.dqrkis.module.modules.cosmetic;

import java.awt.Color;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.ColorSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.EncryptedString;

public final class Wings extends Module {
   public final ColorSetting color = new ColorSetting(EncryptedString.of("Color"), new Color(180, 60, 255, 190));
   public final NumberSetting scale = new NumberSetting(EncryptedString.of("Scale"), 0.5, 1.8, 1.0, 0.1);
   public Wings() {
      super(EncryptedString.of("Wings"), EncryptedString.of("GodWeer-style cosmetic wings"), -1, Category.COSMETIC);
      addSettings(color, scale);
   }
}
