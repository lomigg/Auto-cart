package xyz.dqrkis.module.modules.cosmetic;

import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.EncryptedString;

public final class CustomModel extends Module {
   public enum Model { Rabbit, Chinchilla, Crab, Demon, Freddy, Jeff, Sonic, Amogus, Cuphead, WhiteDemon }
   public final ModeSetting<Model> model = new ModeSetting<>(EncryptedString.of("Model"), Model.Rabbit, Model.class);
   public final NumberSetting scale = new NumberSetting(EncryptedString.of("Scale"), 0.4, 1.8, 1.0, 0.1);
   public CustomModel() {
      super(EncryptedString.of("Custom Model"), EncryptedString.of("GodWeer-style cosmetic model selector"), -1, Category.COSMETIC);
      addSettings(model, scale);
   }
}
