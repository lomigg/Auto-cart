# AutoCart 1.21.11 source

This source keeps the AutoCart module system and glass-style GUI, and adds a separate Cosmetic category inspired by the cosmetic set in the supplied GodWeer source.

Cosmetics included: Cat Ears, China Hat, Wings, Trails, Jump Circle and Custom Model. The implementation is self-contained in the `xyz.dqrkis.module.modules.cosmetic` package and does not depend on GodWeer classes.

Build with the project's existing Gradle/Loom setup.
