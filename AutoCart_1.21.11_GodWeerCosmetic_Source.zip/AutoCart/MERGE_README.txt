AutoCart 1.21.11 - AutoCart GUI + GodWeer-inspired cosmetic layer

Changes:
- AutoCart GUI remains the native glass-style GUI.
- Added a dedicated Cosmetic category.
- Added Cat Ears, China Hat, Wings, Trails, Jump Circle and Custom Model cosmetic modules.
- Cosmetic rendering is implemented locally in AutoCart; no gg.godweer classes, event bus, gameplay modules or GodWeer runtime dependencies are imported.
- Added cosmetic model preview assets from the supplied GodWeer project under assets/autocart/cosmetics/models.
- AutoCart module names/settings remain owned by AutoCart.
