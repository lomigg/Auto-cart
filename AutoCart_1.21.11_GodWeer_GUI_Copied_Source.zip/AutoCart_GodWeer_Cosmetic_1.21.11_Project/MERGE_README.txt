Merged source: AutoCart + GodWeer CatEars cosmetic

Base: file 1 (packetfixer decompiler source)
AutoCart: xyz/dqrkis/module/modules/cart/Cart.java (unchanged)
Cosmetic: CatEars source adapted from GodWeer
GodWeer combat/cheat modules and its large model library are NOT included.

IMPORTANT: file 1 is decompiler output and contains no Gradle/Loom build files.
The PlayerEntityRenderer mixin is an integration point and must be mapped against the
exact Yarn 1.21.11 environment before building.
