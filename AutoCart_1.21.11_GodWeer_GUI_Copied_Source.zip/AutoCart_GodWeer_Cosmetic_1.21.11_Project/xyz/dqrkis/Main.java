package xyz.dqrkis;

import java.io.IOException;
import net.fabricmc.api.ModInitializer;

public final class Main implements ModInitializer {
   public void onInitialize() {
      try {
         new Dqrkis();
      } catch (IOException | InterruptedException var2) {
      }

   }
}
