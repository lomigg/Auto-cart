package xyz.dqrkis.gui;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;
import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.module.setting.Setting;
import xyz.dqrkis.module.setting.StringSetting;

public final class TabGui extends class_437 {
   private static final int TAB_WIDTH = 78;
   private static final int TAB_HEIGHT = 14;
   private static final int MODULE_WIDTH = 96;
   private static final int SETTING_WIDTH = 110;
   private static final Color BG = new Color(18, 18, 20, 240);
   private static final Color SELECTED = new Color(255, 68, 68, 255);
   private static final Color HOVER = new Color(255, 255, 255, 255);
   private static final Color IDLE = new Color(160, 160, 160, 255);
   private static final Color ENABLED = new Color(255, 68, 68, 255);
   private int selectedCategory = 0;
   private int selectedModule = 0;
   private int selectedSetting = -1;
   private final List<Category> categories = new ArrayList();

   public TabGui() {
      super(class_2561.method_43470("TabGui"));
      this.categories.addAll(List.of(Category.values()));
   }

   protected void method_25426() {
      this.selectedCategory = 0;
      this.selectedModule = 0;
      this.selectedSetting = -1;
   }

   private List<Module> getModules(Category category) {
      return Dqrkis.INSTANCE.getModuleManager().getModulesInCategory(category);
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      class_327 textRenderer = class_310.method_1551().field_1772;
      int baseX = 6;
      int baseY = 18;

      for(int i = 0; i < this.categories.size(); ++i) {
         Category cat = (Category)this.categories.get(i);
         if (i == this.selectedCategory && this.selectedSetting == -1 && this.getSelectedModuleIndex() == -1) {
            boolean var31 = true;
         } else {
            boolean var10000 = false;
         }

         boolean catSel = i == this.selectedCategory;
         int y = baseY + i * 15;
         context.method_25294(baseX, y, baseX + 78, y + 14, catSel ? SELECTED.getRGB() : BG.getRGB());
         if (catSel) {
            context.method_25294(baseX, y, baseX + 2, y + 14, SELECTED.brighter().getRGB());
         }

         int color = catSel ? -1 : IDLE.getRGB();
         context.method_51439(textRenderer, class_2561.method_43470(cat.name.toString()), baseX + 6, y + 4, color, false);
      }

      Category cat = (Category)this.categories.get(this.selectedCategory);
      List<Module> modules = this.getModules(cat);
      int modX = baseX + 78 + 2;

      for(int i = 0; i < modules.size(); ++i) {
         Module m = (Module)modules.get(i);
         boolean sel = i == this.selectedModule && this.selectedSetting == -1;
         int y = baseY + i * 15;
         Color bg = m.isEnabled() ? ENABLED : BG;
         if (sel) {
            bg = SELECTED;
         }

         context.method_25294(modX, y, modX + 96, y + 14, bg.getRGB());
         if (sel) {
            context.method_25294(modX, y, modX + 2, y + 14, Color.WHITE.getRGB());
         }

         int color = m.isEnabled() ? -1 : (sel ? -1 : IDLE.getRGB());
         String name = m.getName().toString();
         if (textRenderer.method_1727(name) > 86) {
            name = textRenderer.method_27523(name, 84);
         }

         context.method_51439(textRenderer, class_2561.method_43470(name), modX + 4, y + 4, color, false);
         if (!m.getSettings().isEmpty()) {
            context.method_51439(textRenderer, class_2561.method_43470(sel ? ">" : "…"), modX + 96 - 10, y + 4, -7829368, false);
         }
      }

      if (this.selectedSetting != -1 || this.selectedModule >= 0 && this.selectedModule < modules.size() && !((Module)modules.get(this.selectedModule)).getSettings().isEmpty()) {
         int activeModuleIdx = this.selectedModule >= 0 && this.selectedModule < modules.size() ? this.selectedModule : 0;
         if (activeModuleIdx < modules.size()) {
            Module active = (Module)modules.get(activeModuleIdx);
            int settingX = modX + 96 + 2;
            List<?> settings = active.getSettings();

            for(int i = 0; i < settings.size(); ++i) {
               boolean sel = i == this.selectedSetting;
               int y = baseY + i * 15;
               context.method_25294(settingX, y, settingX + 110, y + 14, sel ? SELECTED.getRGB() : BG.getRGB());
               if (sel) {
                  context.method_25294(settingX, y, settingX + 2, y + 14, Color.WHITE.getRGB());
               }

               String label = this.getSettingDisplay(active.getSettings().get(i));
               if (textRenderer.method_1727(label) > 102) {
                  label = textRenderer.method_27523(label, 100);
               }

               context.method_51439(textRenderer, class_2561.method_43470(label), settingX + 4, y + 4, sel ? -1 : IDLE.getRGB(), false);
            }
         }
      }

      context.method_51439(textRenderer, class_2561.method_43470("TabGUI — Arrows:Navigate  Enter:Toggle/Edit  ESC:Close"), baseX, this.field_22790 - 12, -10066330, false);
   }

   private String getSettingDisplay(Object setting) {
      if (setting instanceof BooleanSetting bs) {
         String var11 = String.valueOf(bs.getName());
         return var11 + ": " + (bs.getValue() ? "ON" : "OFF");
      } else if (setting instanceof NumberSetting ns) {
         String var10 = String.valueOf(ns.getName());
         return var10 + ": " + ns.getValue();
      } else if (setting instanceof ModeSetting<?> ms) {
         String var9 = String.valueOf(ms.getName());
         return var9 + ": " + String.valueOf(ms.getMode());
      } else if (setting instanceof KeybindSetting ks) {
         String var8 = String.valueOf(ks.getName());
         return var8 + ": " + String.valueOf(ks.getKey() == -1 ? "NONE" : ks.getKey());
      } else if (setting instanceof StringSetting ss) {
         String v = ss.getValue();
         String var10000 = String.valueOf(ss.getName());
         return var10000 + ": " + (v.length() > 8 ? v.substring(0, 8) + "…" : v);
      } else {
         return setting.toString();
      }
   }

   private int getSelectedModuleIndex() {
      return this.selectedModule;
   }

   public boolean method_25402(class_11909 click, boolean doubled) {
      double mouseX = click.comp_4798();
      double mouseY = click.comp_4799();
      int button = click.method_74245();
      int baseX = 6;
      int baseY = 18;

      for(int i = 0; i < this.categories.size(); ++i) {
         int y = baseY + i * 15;
         if (mouseX >= (double)baseX && mouseX < (double)(baseX + 78) && mouseY >= (double)y && mouseY < (double)(y + 14)) {
            this.selectedCategory = i;
            this.selectedModule = 0;
            this.selectedSetting = -1;
            return true;
         }
      }

      Category cat = (Category)this.categories.get(this.selectedCategory);
      List<Module> modules = this.getModules(cat);
      int modX = baseX + 78 + 2;

      for(int i = 0; i < modules.size(); ++i) {
         int y = baseY + i * 15;
         if (mouseX >= (double)modX && mouseX < (double)(modX + 96) && mouseY >= (double)y && mouseY < (double)(y + 14)) {
            this.selectedModule = i;
            this.selectedSetting = -1;
            if (button == 0) {
               ((Module)modules.get(i)).toggle();
            } else if (button == 1 && !((Module)modules.get(i)).getSettings().isEmpty()) {
               this.selectedSetting = 0;
            }

            return true;
         }
      }

      return super.method_25402(click, doubled);
   }

   public boolean method_25404(class_11908 keyInput) {
      int key = keyInput.comp_4795();
      Category cat = (Category)this.categories.get(this.selectedCategory);
      List<Module> modules = this.getModules(cat);
      if (key == 256) {
         if (this.selectedSetting != -1) {
            this.selectedSetting = -1;
            return true;
         } else if (this.selectedModule == 0 && this.selectedCategory == 0) {
            this.method_25419();
            return true;
         } else {
            this.method_25419();
            return true;
         }
      } else if (key == 265) {
         if (this.selectedSetting != -1) {
            this.selectedSetting = Math.max(-1, this.selectedSetting - 1);
         } else if (!modules.isEmpty() && this.selectedModule >= 0) {
            this.selectedModule = Math.max(0, this.selectedModule - 1);
         } else {
            this.selectedCategory = Math.max(0, this.selectedCategory - 1);
         }

         return true;
      } else if (key == 264) {
         if (this.selectedSetting != -1) {
            Module m = (Module)modules.get(this.selectedModule);
            this.selectedSetting = Math.min(m.getSettings().size() - 1, this.selectedSetting + 1);
         } else if (!modules.isEmpty() && this.selectedModule >= 0) {
            this.selectedModule = Math.min(modules.size() - 1, this.selectedModule + 1);
         } else {
            this.selectedCategory = Math.min(this.categories.size() - 1, this.selectedCategory + 1);
         }

         return true;
      } else if (key == 263) {
         if (this.selectedSetting != -1) {
            this.selectedSetting = -1;
            return true;
         } else {
            this.selectedModule = -1;
            return true;
         }
      } else {
         if (key == 262 || key == 257 || key == 335) {
            if (this.selectedSetting == -1 && !modules.isEmpty() && this.selectedModule >= 0) {
               Module m = (Module)modules.get(this.selectedModule);
               if (!m.getSettings().isEmpty()) {
                  this.selectedSetting = 0;
                  return true;
               }

               m.toggle();
               return true;
            }

            if (this.selectedSetting != -1) {
               Module m = (Module)modules.get(this.selectedModule);
               Setting<? extends Setting<?>> s = (Setting)m.getSettings().get(this.selectedSetting);
               if (s instanceof BooleanSetting) {
                  BooleanSetting bs = (BooleanSetting)s;
                  bs.setValue(!bs.getValue());
               } else if (s instanceof NumberSetting) {
                  NumberSetting ns = (NumberSetting)s;
                  ns.setValue(ns.getValue() + ns.getIncrement());
               } else if (s instanceof ModeSetting) {
                  ModeSetting<?> ms = (ModeSetting)s;
                  ms.cycle();
               } else if (s instanceof KeybindSetting) {
                  KeybindSetting ks = (KeybindSetting)s;
                  ks.setListening(!ks.isListening());
               }

               return true;
            }

            if (this.selectedModule == -1) {
               this.selectedModule = 0;
               return true;
            }
         }

         if (key == 257 && this.selectedSetting == -1 && !modules.isEmpty()) {
            ((Module)modules.get(this.selectedModule)).toggle();
            return true;
         } else {
            return super.method_25404(keyInput);
         }
      }
   }

   public boolean method_25421() {
      return false;
   }
}
