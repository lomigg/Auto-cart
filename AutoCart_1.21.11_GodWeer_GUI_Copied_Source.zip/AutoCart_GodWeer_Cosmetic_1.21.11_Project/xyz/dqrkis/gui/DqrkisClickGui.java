package xyz.dqrkis.gui;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.module.setting.Setting;
import xyz.dqrkis.module.setting.StringSetting;

public final class DqrkisClickGui extends class_437 {
   private static final int SIDEBAR_WIDTH = 78;
   private static final int HEADER_HEIGHT = 18;
   private static final int MODULE_HEIGHT = 16;
   private static final int SETTING_HEIGHT = 14;
   private static final Color SIDEBAR_BG = new Color(18, 18, 20, 255);
   private static final Color CONTENT_BG = new Color(24, 24, 28, 255);
   private static final Color MODULE_BG = new Color(32, 32, 36, 255);
   private static final Color MODULE_ENABLED = new Color(255, 68, 68, 255);
   private static final Color MODULE_HOVER = new Color(45, 45, 50, 255);
   private static final Color CATEGORY_SELECTED = new Color(255, 68, 68, 255);
   private static final Color CATEGORY_IDLE = new Color(160, 160, 160, 255);
   private static final Color SEARCH_BG = new Color(38, 38, 42, 255);
   private Category selectedCategory;
   private final List<Category> categories = new ArrayList();
   private String searchQuery = "";
   private boolean searchFocused;
   private int guiLeft;
   private int guiTop;
   private int guiWidth;
   private int guiHeight;
   private int contentLeft;
   private float scroll;
   private final Set<Module> expandedModules = new HashSet();

   public DqrkisClickGui() {
      super(class_2561.method_43470("Dqrkis"));

      for(Category category : Category.values()) {
         this.categories.add(category);
      }

      this.selectedCategory = (Category)this.categories.getFirst();
   }

   protected void method_25426() {
      this.guiWidth = Math.min(520, this.field_22789 - 40);
      this.guiHeight = Math.min(340, this.field_22790 - 40);
      this.guiLeft = (this.field_22789 - this.guiWidth) / 2;
      this.guiTop = (this.field_22790 - this.guiHeight) / 2;
      this.contentLeft = this.guiLeft + 78;
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      class_327 textRenderer = class_310.method_1551().field_1772;
      if (Dqrkis.INSTANCE.previousScreen != null) {
         Dqrkis.INSTANCE.previousScreen.method_25394(context, 0, 0, delta);
      }

      context.method_25294(0, 0, this.field_22789, this.field_22790, Integer.MIN_VALUE);
      context.method_25294(this.guiLeft - 1, this.guiTop - 1, this.guiLeft + this.guiWidth + 1, this.guiTop + this.guiHeight + 1, (new Color(50, 50, 55)).getRGB());
      context.method_25294(this.guiLeft, this.guiTop, this.guiLeft + this.guiWidth, this.guiTop + this.guiHeight, CONTENT_BG.getRGB());
      context.method_25294(this.guiLeft, this.guiTop, this.contentLeft, this.guiTop + this.guiHeight, SIDEBAR_BG.getRGB());
      context.method_51439(textRenderer, class_2561.method_43470("Dqrkis |"), this.guiLeft + 8, this.guiTop + 6, -1, false);
      int headerBottom = this.guiTop + 18;
      int searchY = headerBottom + 4;
      int searchH = 14;
      context.method_25294(this.guiLeft + 6, searchY, this.contentLeft - 6, searchY + searchH, SEARCH_BG.getRGB());
      int borderColor = this.searchFocused ? MODULE_ENABLED.getRGB() : -12961216;
      context.method_25294(this.guiLeft + 6, searchY, this.contentLeft - 6, searchY + 1, borderColor);
      context.method_25294(this.guiLeft + 6, searchY + searchH - 1, this.contentLeft - 6, searchY + searchH, borderColor);
      context.method_25294(this.guiLeft + 6, searchY, this.guiLeft + 7, searchY + searchH, borderColor);
      context.method_25294(this.contentLeft - 7, searchY, this.contentLeft - 6, searchY + searchH, borderColor);
      String searchDisplay = this.searchQuery.isEmpty() && !this.searchFocused ? "Search..." : this.searchQuery + (this.searchFocused && System.currentTimeMillis() / 500L % 2L == 0L ? "_" : "");
      context.method_51439(textRenderer, class_2561.method_43470(searchDisplay), this.guiLeft + 10, searchY + 4, this.searchQuery.isEmpty() && !this.searchFocused ? -7829368 : -1, false);
      int categoryY = searchY + searchH + 8;

      for(Category category : this.categories) {
         boolean selected = category == this.selectedCategory;
         int color = selected ? CATEGORY_SELECTED.getRGB() : CATEGORY_IDLE.getRGB();
         boolean hovered = mouseX >= this.guiLeft && mouseX < this.contentLeft && mouseY >= categoryY && mouseY < categoryY + 16;
         if (hovered && !selected) {
            color = -1;
         }

         context.method_51439(textRenderer, class_2561.method_43470(category.name.toString()), this.guiLeft + 10, categoryY + 4, color, false);
         if (selected) {
            context.method_25294(this.guiLeft, categoryY, this.guiLeft + 2, categoryY + 16, CATEGORY_SELECTED.getRGB());
         }

         categoryY += 18;
      }

      List<Module> modules = this.getVisibleModules();
      int contentWidth = this.guiWidth - 78;
      int startY = this.guiTop + 6 - (int)this.scroll;
      int moduleY = startY;
      context.method_44379(this.contentLeft, this.guiTop, this.guiLeft + this.guiWidth, this.guiTop + this.guiHeight);

      for(Module module : modules) {
         if (moduleY + 16 >= this.guiTop && moduleY <= this.guiTop + this.guiHeight) {
            boolean hovered = mouseX >= this.contentLeft + 6 && mouseX < this.guiLeft + this.guiWidth - 6 && mouseY >= moduleY && mouseY < moduleY + 16;
            Color bg = module.isEnabled() ? MODULE_ENABLED : (hovered ? MODULE_HOVER : MODULE_BG);
            context.method_25294(this.contentLeft + 6, moduleY, this.guiLeft + this.guiWidth - 6, moduleY + 16, bg.getRGB());
            context.method_25294(this.contentLeft + 6, moduleY, this.contentLeft + 8, moduleY + 16, module.isEnabled() ? MODULE_ENABLED.brighter().getRGB() : -12961216);
            int textColor = module.isEnabled() ? -1 : -3355444;
            context.method_51439(textRenderer, class_2561.method_43470(module.getName().toString()), this.contentLeft + 14, moduleY + 5, textColor, false);
            if (module.getKey() != -1) {
               String keyName = this.getKeyName(module.getKey());
               int keyW = textRenderer.method_1727(keyName);
               int pillX = this.guiLeft + this.guiWidth - 10 - keyW - 6;
               context.method_25294(pillX, moduleY + 3, pillX + keyW + 6, moduleY + 13, (new Color(0, 0, 0, 100)).getRGB());
               context.method_51439(textRenderer, class_2561.method_43470(keyName), pillX + 3, moduleY + 5, -5592406, false);
            }

            if (!module.getSettings().isEmpty()) {
               String indicator = this.isExpanded(module) ? "−" : "+";
               context.method_51439(textRenderer, class_2561.method_43470(indicator), this.guiLeft + this.guiWidth - 18, moduleY + 5, -7829368, false);
            }

            moduleY += 17;
            if (this.isExpanded(module)) {
               for(Setting<?> setting : module.getSettings()) {
                  if (moduleY + 14 >= this.guiTop && moduleY <= this.guiTop + this.guiHeight) {
                     context.method_25294(this.contentLeft + 10, moduleY, this.guiLeft + this.guiWidth - 10, moduleY + 14, (new Color(28, 28, 32)).getRGB());
                     this.renderSetting(context, setting, this.contentLeft + 14, moduleY + 4, mouseX, mouseY);
                     moduleY += 15;
                  } else {
                     moduleY += 15;
                  }
               }

               moduleY += 2;
            }
         } else {
            moduleY += 17;
            if (moduleY + this.getSettingsHeight(module) > this.guiTop) {
               moduleY += this.getSettingsHeight(module);
            }
         }
      }

      context.method_44380();
      int totalContentHeight = modules.size() * 17 + this.getTotalSettingsHeight(modules) + 12;
      if (totalContentHeight > this.guiHeight) {
         float visibleRatio = (float)this.guiHeight / (float)totalContentHeight;
         int barH = Math.max(20, (int)((float)this.guiHeight * visibleRatio));
         float maxScroll = (float)(totalContentHeight - this.guiHeight);
         float barY = (float)this.guiTop + this.scroll / maxScroll * (float)(this.guiHeight - barH);
         context.method_25294(this.guiLeft + this.guiWidth - 3, (int)barY, this.guiLeft + this.guiWidth - 1, (int)barY + barH, -11184811);
      }

   }

   private void renderSetting(class_332 context, Setting<?> setting, int x, int y, int mouseX, int mouseY) {
      class_327 textRenderer = class_310.method_1551().field_1772;
      String name = setting.getName().toString();
      String valueStr = this.getSettingValueString(setting);
      int valueColor = -5592406;
      if (setting instanceof BooleanSetting bs) {
         valueColor = bs.getValue() ? MODULE_ENABLED.getRGB() : -7829368;
      } else if (setting instanceof NumberSetting) {
         valueColor = -13210;
      } else if (setting instanceof ModeSetting) {
         valueColor = -7811841;
      }

      context.method_51439(textRenderer, class_2561.method_43470(name), x, y, -4473925, false);
      int valueW = textRenderer.method_1727(valueStr);
      context.method_51439(textRenderer, class_2561.method_43470(valueStr), this.contentLeft + (this.guiWidth - 78) - valueW - 14, y, valueColor, false);
   }

   private String getSettingValueString(Setting<?> setting) {
      if (setting instanceof BooleanSetting bs) {
         return bs.getValue() ? "ON" : "OFF";
      } else if (setting instanceof NumberSetting ns) {
         return String.valueOf(ns.getValue());
      } else if (setting instanceof ModeSetting<?> ms) {
         return ms.getMode().toString();
      } else if (setting instanceof StringSetting ss) {
         String v = ss.getValue();
         return v.length() > 16 ? v.substring(0, 16) + "…" : v;
      } else if (setting instanceof KeybindSetting ks) {
         int k = ks.getKey();
         return k == -1 ? "NONE" : this.getKeyName(k);
      } else {
         Object v = null;

         try {
            v = setting.getClass().getMethod("getValue").invoke(setting);
         } catch (Exception var5) {
         }

         if (v == null) {
            try {
               v = setting.getClass().getMethod("getItem").invoke(setting);
            } catch (Exception var4) {
            }
         }

         return v == null ? "" : v.toString().replace("minecraft:", "");
      }
   }

   private String getKeyName(int key) {
      if (key <= 8) {
         String var10000;
         switch (key) {
            case 0 -> var10000 = "LMB";
            case 1 -> var10000 = "RMB";
            case 2 -> var10000 = "MMB";
            default -> var10000 = "M" + key;
         }

         return var10000;
      } else {
         String name = GLFW.glfwGetKeyName(key, 0);
         return name == null ? "KEY" + key : name.toUpperCase();
      }
   }

   private List<Module> getVisibleModules() {
      List<Module> all = Dqrkis.INSTANCE.getModuleManager().getModulesInCategory(this.selectedCategory);
      if (this.searchQuery.isEmpty()) {
         return all;
      } else {
         String q = this.searchQuery.toLowerCase();
         List<Module> filtered = new ArrayList();

         for(Module m : all) {
            if (m.getName().toString().toLowerCase().contains(q)) {
               filtered.add(m);
            }
         }

         return filtered;
      }
   }

   private boolean isExpanded(Module module) {
      return this.expandedModules.contains(module);
   }

   private int getSettingsHeight(Module module) {
      return this.isExpanded(module) ? module.getSettings().size() * 15 + 2 : 0;
   }

   private int getTotalSettingsHeight(List<Module> modules) {
      int h = 0;

      for(Module m : modules) {
         h += this.getSettingsHeight(m);
      }

      return h;
   }

   public boolean method_25402(class_11909 click, boolean doubled) {
      double mouseX = click.comp_4798();
      double mouseY = click.comp_4799();
      int button = click.method_74245();
      int searchY = this.guiTop + 18 + 4;
      boolean inSearch = mouseX >= (double)(this.guiLeft + 6) && mouseX < (double)(this.contentLeft - 6) && mouseY >= (double)searchY && mouseY < (double)(searchY + 14);
      this.searchFocused = inSearch;
      if (inSearch) {
         return true;
      } else {
         int categoryY = searchY + 14 + 8;

         for(Category category : this.categories) {
            if (mouseX >= (double)this.guiLeft && mouseX < (double)this.contentLeft && mouseY >= (double)categoryY && mouseY < (double)(categoryY + 16)) {
               this.selectedCategory = category;
               this.scroll = 0.0F;
               return true;
            }

            categoryY += 18;
         }

         List<Module> modules = this.getVisibleModules();
         int moduleY = this.guiTop + 6 - (int)this.scroll;

         for(Module module : modules) {
            if (mouseX >= (double)(this.contentLeft + 6) && mouseX < (double)(this.guiLeft + this.guiWidth - 6) && mouseY >= (double)moduleY && mouseY < (double)(moduleY + 16)) {
               if (button == 0) {
                  module.toggle();
               } else if (button == 1 && !module.getSettings().isEmpty()) {
                  if (this.expandedModules.contains(module)) {
                     this.expandedModules.remove(module);
                  } else {
                     this.expandedModules.add(module);
                  }
               } else if (button == 2) {
               }

               return true;
            }

            moduleY += 17;
            if (this.isExpanded(module)) {
               for(Setting<?> setting : module.getSettings()) {
                  if (mouseX >= (double)(this.contentLeft + 10) && mouseX < (double)(this.guiLeft + this.guiWidth - 10) && mouseY >= (double)moduleY && mouseY < (double)(moduleY + 14)) {
                     this.handleSettingClick(setting, button, mouseX);
                     return true;
                  }

                  moduleY += 15;
               }

               moduleY += 2;
            }
         }

         return super.method_25402(click, doubled);
      }
   }

   private void handleSettingClick(Setting<?> setting, int button, double mouseX) {
      if (setting instanceof BooleanSetting bs) {
         if (button == 0) {
            bs.setValue(!bs.getValue());
         }
      } else if (setting instanceof NumberSetting ns) {
         double step = ns.getIncrement();
         double delta = button == 0 ? step : -step;
         ns.setValue(ns.getValue() + delta);
      } else if (setting instanceof ModeSetting<?> ms) {
         if (button == 0) {
            ms.cycle();
         }
      } else if (setting instanceof KeybindSetting ks) {
         ks.setListening(!ks.isListening());
      }

   }

   public boolean method_25404(class_11908 keyInput) {
      int keyCode = keyInput.comp_4795();
      if (this.searchFocused) {
         if (keyCode == 256) {
            this.searchFocused = false;
            return true;
         } else if (keyCode == 259) {
            if (!this.searchQuery.isEmpty()) {
               this.searchQuery = this.searchQuery.substring(0, this.searchQuery.length() - 1);
            }

            return true;
         } else if (keyCode == 257) {
            this.searchFocused = false;
            return true;
         } else {
            return true;
         }
      } else if (keyCode == 256) {
         this.method_25419();
         return true;
      } else {
         for(Module m : Dqrkis.INSTANCE.getModuleManager().getModules()) {
            for(Setting<?> s : m.getSettings()) {
               if (s instanceof KeybindSetting) {
                  KeybindSetting ks = (KeybindSetting)s;
                  if (ks.isListening()) {
                     ks.setKey(keyCode);
                     ks.setListening(false);
                     return true;
                  }
               }
            }
         }

         return super.method_25404(keyInput);
      }
   }

   public boolean method_25400(class_11905 charInput) {
      if (this.searchFocused) {
         String s = charInput.method_74226();
         if (!s.isEmpty()) {
            char chr = s.charAt(0);
            if (chr >= ' ' && chr < 127) {
               this.searchQuery = this.searchQuery + chr;
            }
         }

         return true;
      } else {
         return super.method_25400(charInput);
      }
   }

   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      List<Module> modules = this.getVisibleModules();
      int totalH = modules.size() * 17 + this.getTotalSettingsHeight(modules) + 12;
      int maxScroll = Math.max(0, totalH - this.guiHeight);
      this.scroll = (float)Math.max((double)0.0F, Math.min((double)maxScroll, (double)this.scroll - verticalAmount * (double)16.0F));
      return true;
   }

   public boolean method_25421() {
      return false;
   }
}
