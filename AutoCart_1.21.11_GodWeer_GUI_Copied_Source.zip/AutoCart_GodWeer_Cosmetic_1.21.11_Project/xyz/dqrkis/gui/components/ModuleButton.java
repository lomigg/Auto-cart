package xyz.dqrkis.gui.components;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;
import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.gui.Window;
import xyz.dqrkis.gui.components.settings.CheckBox;
import xyz.dqrkis.gui.components.settings.ColorPickerBox;
import xyz.dqrkis.gui.components.settings.ItemSettingBox;
import xyz.dqrkis.gui.components.settings.KeybindBox;
import xyz.dqrkis.gui.components.settings.MinMaxSlider;
import xyz.dqrkis.gui.components.settings.ModeBox;
import xyz.dqrkis.gui.components.settings.RenderableSetting;
import xyz.dqrkis.gui.components.settings.Slider;
import xyz.dqrkis.gui.components.settings.StringBox;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.modules.client.ClickGUI;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.ColorSetting;
import xyz.dqrkis.module.setting.ItemSetting;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.module.setting.MinMaxSetting;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.module.setting.Setting;
import xyz.dqrkis.module.setting.StringSetting;
import xyz.dqrkis.utils.AnimationUtils;
import xyz.dqrkis.utils.ColorUtils;
import xyz.dqrkis.utils.RenderUtils;
import xyz.dqrkis.utils.TextRenderer;
import xyz.dqrkis.utils.Utils;

public final class ModuleButton {
   public List<RenderableSetting> settings = new ArrayList();
   public Window parent;
   public Module module;
   public int offset;
   public boolean extended;
   public int settingOffset;
   public Color currentColor;
   public Color defaultColor;
   public Color currentAlpha;
   public AnimationUtils animation;

   public ModuleButton(Window parent, Module module, int offset) {
      this.defaultColor = Color.WHITE;
      this.animation = new AnimationUtils((double)0.0F);
      this.parent = parent;
      this.module = module;
      this.offset = offset;
      this.extended = false;
      this.settingOffset = parent.getHeight();

      for(Setting<?> setting : module.getSettings()) {
         if (setting instanceof BooleanSetting booleanSetting) {
            this.settings.add(new CheckBox(this, booleanSetting, this.settingOffset));
         } else if (setting instanceof NumberSetting numberSetting) {
            this.settings.add(new Slider(this, numberSetting, this.settingOffset));
         } else if (setting instanceof ModeSetting<?> modeSetting) {
            this.settings.add(new ModeBox(this, modeSetting, this.settingOffset));
         } else if (setting instanceof KeybindSetting keybindSetting) {
            this.settings.add(new KeybindBox(this, keybindSetting, this.settingOffset));
         } else if (setting instanceof StringSetting stringSetting) {
            this.settings.add(new StringBox(this, stringSetting, this.settingOffset));
         } else if (setting instanceof MinMaxSetting minMaxSetting) {
            this.settings.add(new MinMaxSlider(this, minMaxSetting, this.settingOffset));
         } else if (setting instanceof ItemSetting itemSetting) {
            this.settings.add(new ItemSettingBox(this, itemSetting, this.settingOffset));
         } else if (setting instanceof ColorSetting colorSetting) {
            this.settings.add(new ColorPickerBox(this, colorSetting, this.settingOffset));
         }

         this.settingOffset += parent.getHeight();
      }

   }

   public void render(class_332 context, int mouseX, int mouseY, float delta) {
      if (this.parent.getY() + this.offset <= class_310.method_1551().method_22683().method_4507()) {
         for(RenderableSetting renderableSetting : this.settings) {
            renderableSetting.onUpdate();
         }

         if (this.currentColor == null) {
            this.currentColor = new Color(0, 0, 0, 0);
         } else {
            this.currentColor = new Color(0, 0, 0, this.currentColor.getAlpha());
         }

         int toAlpha = 170;
         this.currentColor = ColorUtils.smoothAlphaTransition(0.05F, toAlpha, this.currentColor);
         Color toColor = this.module.isEnabled() ? Utils.getMainColor(255, Dqrkis.INSTANCE.getModuleManager().getModulesInCategory(this.module.getCategory()).indexOf(this.module)) : Color.WHITE;
         if (this.defaultColor != toColor) {
            this.defaultColor = ColorUtils.smoothColorTransition(0.1F, toColor, this.defaultColor);
         }

         if (this.parent.moduleButtons.get(this.parent.moduleButtons.size() - 1) != this) {
            context.method_25294(this.parent.getX(), this.parent.getY() + this.offset, this.parent.getX() + this.parent.getWidth(), this.parent.getY() + this.parent.getHeight() + this.offset, this.currentColor.getRGB());
            context.method_25296(this.parent.getX(), this.parent.getY() + this.offset, this.parent.getX() + 2, this.parent.getY() + this.parent.getHeight() + this.offset, Utils.getMainColor(255, Dqrkis.INSTANCE.getModuleManager().getModulesInCategory(this.module.getCategory()).indexOf(this.module)).getRGB(), Utils.getMainColor(255, Dqrkis.INSTANCE.getModuleManager().getModulesInCategory(this.module.getCategory()).indexOf(this.module) + 1).getRGB());
         } else {
            RenderUtils.renderRoundedQuad(context, this.currentColor, (double)this.parent.getX(), (double)(this.parent.getY() + this.offset), (double)(this.parent.getX() + this.parent.getWidth()), (double)(this.parent.getY() + this.parent.getHeight() + this.offset), (double)0.0F, (double)0.0F, (double)3.0F, this.animation.getValue() > (double)30.0F ? (double)0.0F : (double)ClickGUI.roundQuads.getValueInt(), (double)50.0F);
            RenderUtils.renderRoundedQuad(context, Utils.getMainColor(255, Dqrkis.INSTANCE.getModuleManager().getModulesInCategory(this.module.getCategory()).indexOf(this.module)), (double)this.parent.getX(), (double)(this.parent.getY() + this.offset), (double)(this.parent.getX() + 2), (double)(this.parent.getY() + (this.parent.getHeight() - 1) + this.offset), (double)0.0F, (double)0.0F, this.extended ? (double)0.0F : (double)2.0F, (double)0.0F, (double)50.0F);
         }

         CharSequence nameChars = this.module.getName();
         int totalWidth = TextRenderer.getWidth(nameChars);
         int parentCenterX = this.parent.getX() + this.parent.getWidth() / 2;
         int textCenterX = parentCenterX - totalWidth / 2;
         TextRenderer.drawString(nameChars, context, textCenterX, this.parent.getY() + this.offset + 8, this.defaultColor.getRGB());
         this.renderHover(context, mouseX, mouseY, delta);
         this.renderSettings(context, mouseX, mouseY, delta);

         for(RenderableSetting renderableSetting : this.settings) {
            if (this.extended) {
               renderableSetting.renderDescription(context, mouseX, mouseY, delta);
            }
         }

         if (this.isHovered((double)mouseX, (double)mouseY) && !this.parent.dragging) {
            CharSequence chars = this.module.getDescription();
            int tw = TextRenderer.getWidth(chars);
            int parentCenter = Dqrkis.mc.method_22683().method_4489() / 2;
            int textCenter = parentCenter - tw / 2;
            RenderUtils.renderRoundedQuad(context, new Color(100, 100, 100, 100), (double)(textCenter - 5), (double)Dqrkis.mc.method_22683().method_4506() / (double)2.0F + (double)294.0F, (double)(textCenter + tw + 5), (double)Dqrkis.mc.method_22683().method_4506() / (double)2.0F + (double)318.0F, (double)3.0F, (double)10.0F);
            TextRenderer.drawString(chars, context, textCenter, Dqrkis.mc.method_22683().method_4506() / 2 + 300, Color.WHITE.getRGB());
         }

      }
   }

   private void renderHover(class_332 context, int mouseX, int mouseY, float delta) {
      if (!this.parent.dragging) {
         int toHoverAlpha = this.isHovered((double)mouseX, (double)mouseY) ? 15 : 0;
         if (this.currentAlpha == null) {
            this.currentAlpha = new Color(255, 255, 255, toHoverAlpha);
         } else {
            this.currentAlpha = new Color(255, 255, 255, this.currentAlpha.getAlpha());
         }

         if (this.currentAlpha.getAlpha() != toHoverAlpha) {
            this.currentAlpha = ColorUtils.smoothAlphaTransition(0.05F, toHoverAlpha, this.currentAlpha);
         }

         context.method_25294(this.parent.getX(), this.parent.getY() + this.offset, this.parent.getX() + this.parent.getWidth(), this.parent.getY() + this.parent.getHeight() + this.offset, this.currentAlpha.getRGB());
      }

   }

   private void renderSettings(class_332 context, int mouseX, int mouseY, float delta) {
      int scissorX1 = this.parent.getX();
      int scissorY1 = this.parent.getY() + this.offset;
      int scissorX2 = scissorX1 + this.parent.getWidth();
      int scissorY2 = scissorY1 + (int)this.animation.getValue();
      context.method_44379(scissorX1, scissorY1, scissorX2, scissorY2);

      for(RenderableSetting renderableSetting : this.settings) {
         if (this.animation.getValue() > (double)this.parent.getHeight()) {
            renderableSetting.render(context, mouseX, mouseY, delta);
         }
      }

      for(RenderableSetting renderableSetting : this.settings) {
         if (this.animation.getValue() > (double)this.parent.getHeight()) {
            if (renderableSetting instanceof Slider) {
               Slider slider = (Slider)renderableSetting;
               RenderUtils.renderCircle(context, new Color(0, 0, 0, 170), (double)slider.parentX() + Math.max(slider.lerpedOffsetX, (double)2.5F), (double)(slider.parentY() + slider.offset + slider.parentOffset()) + (double)27.5F, (double)6.0F, 15);
               RenderUtils.renderCircle(context, slider.currentColor1.brighter(), (double)slider.parentX() + Math.max(slider.lerpedOffsetX, (double)2.5F), (double)(slider.parentY() + slider.offset + slider.parentOffset()) + (double)27.5F, (double)5.0F, 15);
            } else if (renderableSetting instanceof MinMaxSlider) {
               MinMaxSlider slider = (MinMaxSlider)renderableSetting;
               RenderUtils.renderCircle(context, new Color(0, 0, 0, 170), (double)slider.parentX() + Math.max(slider.lerpedOffsetMinX, (double)2.5F), (double)(slider.parentY() + slider.offset + slider.parentOffset()) + (double)27.5F, (double)6.0F, 15);
               RenderUtils.renderCircle(context, slider.currentColor1.brighter(), (double)slider.parentX() + Math.max(slider.lerpedOffsetMinX, (double)2.5F), (double)(slider.parentY() + slider.offset + slider.parentOffset()) + (double)27.5F, (double)5.0F, 15);
               RenderUtils.renderCircle(context, new Color(0, 0, 0, 170), (double)slider.parentX() + Math.max(slider.lerpedOffsetMaxX, (double)2.5F), (double)(slider.parentY() + slider.offset + slider.parentOffset()) + (double)27.5F, (double)6.0F, 15);
               RenderUtils.renderCircle(context, slider.currentColor1.brighter(), (double)slider.parentX() + Math.max(slider.lerpedOffsetMaxX, (double)2.5F), (double)(slider.parentY() + slider.offset + slider.parentOffset()) + (double)27.5F, (double)5.0F, 15);
            }
         }
      }

      context.method_44380();
   }

   public void onExtend() {
      for(ModuleButton moduleButton : this.parent.moduleButtons) {
         moduleButton.extended = false;
      }

   }

   public void keyPressed(int keyCode, int scanCode, int modifiers) {
      for(RenderableSetting setting : this.settings) {
         setting.keyPressed(keyCode, scanCode, modifiers);
      }

   }

   public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      if (this.extended) {
         for(RenderableSetting renderableSetting : this.settings) {
            renderableSetting.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
         }
      }

   }

   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isHovered(mouseX, mouseY)) {
         if (button == 0) {
            this.module.toggle();
         }

         if (button == 1) {
            if (this.module.getSettings().isEmpty()) {
               return;
            }

            if (!this.extended) {
               this.onExtend();
            }

            this.extended = !this.extended;
         }
      }

      if (this.extended) {
         for(RenderableSetting renderableSetting : this.settings) {
            renderableSetting.mouseClicked(mouseX, mouseY, button);
         }
      }

   }

   public void onGuiClose() {
      this.currentAlpha = null;
      this.currentColor = null;

      for(RenderableSetting renderableSetting : this.settings) {
         renderableSetting.onGuiClose();
      }

   }

   public void mouseReleased(double mouseX, double mouseY, int button) {
      for(RenderableSetting renderableSetting : this.settings) {
         renderableSetting.mouseReleased(mouseX, mouseY, button);
      }

   }

   public boolean isHovered(double mouseX, double mouseY) {
      return mouseX > (double)this.parent.getX() && mouseX < (double)(this.parent.getX() + this.parent.getWidth()) && mouseY > (double)(this.parent.getY() + this.offset) && mouseY < (double)(this.parent.getY() + this.offset + this.parent.getHeight());
   }
}
