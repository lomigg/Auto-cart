package xyz.dqrkis.gui.components.settings;

import java.awt.Color;
import net.minecraft.class_332;
import xyz.dqrkis.gui.components.ModuleButton;
import xyz.dqrkis.module.setting.Setting;
import xyz.dqrkis.utils.TextRenderer;

public final class BlockSelectorBox extends RenderableSetting {
   private final Setting<?> setting;

   public BlockSelectorBox(ModuleButton parent, Setting<?> setting, int offset) {
      super(parent, setting, offset);
      this.setting = setting;
   }

   public int parentHeight() {
      return 18;
   }

   public void render(class_332 context, int mouseX, int mouseY, float delta) {
      super.render(context, mouseX, mouseY, delta);
      String label = this.setting.getName().toString();
      TextRenderer.drawString(label, context, this.parentX() + 4, this.parentY() + this.offset + 6, Color.WHITE.getRGB());
      String hint = "[RMB: clear]";
      int hintW = TextRenderer.getWidth(hint);
      TextRenderer.drawString(hint, context, this.parentX() + this.parentWidth() - hintW - 4, this.parentY() + this.offset + 6, (new Color(150, 150, 150)).getRGB());
   }

   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isHovered(mouseX, mouseY)) {
         ;
      }
   }
}
