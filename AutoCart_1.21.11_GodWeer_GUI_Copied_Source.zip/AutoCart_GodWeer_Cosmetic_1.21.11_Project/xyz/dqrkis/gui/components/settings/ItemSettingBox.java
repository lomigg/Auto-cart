package xyz.dqrkis.gui.components.settings;

import java.awt.Color;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import xyz.dqrkis.gui.components.ModuleButton;
import xyz.dqrkis.module.setting.ItemSetting;
import xyz.dqrkis.utils.TextRenderer;

public final class ItemSettingBox extends RenderableSetting {
   private final ItemSetting setting;

   public ItemSettingBox(ModuleButton parent, ItemSetting setting, int offset) {
      super(parent, setting, offset);
      this.setting = setting;
   }

   public int parentHeight() {
      return 18;
   }

   public void render(class_332 context, int mouseX, int mouseY, float delta) {
      super.render(context, mouseX, mouseY, delta);
      String var10000 = String.valueOf(this.setting.getName());
      String label = var10000 + ": " + this.setting.getItem().toString().replace("minecraft:", "");
      TextRenderer.drawString(label, context, this.parentX() + 4, this.parentY() + this.offset + 6, Color.WHITE.getRGB());
      class_1799 stack = new class_1799(this.setting.getItem());
      context.method_51427(stack, this.parentX() + this.parentWidth() - 20, this.parentY() + this.offset + 1);
   }

   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isHovered(mouseX, mouseY)) {
         if (button == 0) {
         }

      }
   }
}
