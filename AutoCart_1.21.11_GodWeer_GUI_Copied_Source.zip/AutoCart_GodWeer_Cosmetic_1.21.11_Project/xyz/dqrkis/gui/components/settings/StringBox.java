package xyz.dqrkis.gui.components.settings;

import java.awt.Color;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.gui.components.ModuleButton;
import xyz.dqrkis.module.modules.client.ClickGUI;
import xyz.dqrkis.module.setting.Setting;
import xyz.dqrkis.module.setting.StringSetting;
import xyz.dqrkis.utils.ColorUtils;
import xyz.dqrkis.utils.RenderUtils;
import xyz.dqrkis.utils.TextRenderer;
import xyz.dqrkis.utils.Utils;

public final class StringBox extends RenderableSetting {
   private final StringSetting setting;
   private Color currentAlpha;

   public StringBox(ModuleButton parent, Setting<?> setting, int offset) {
      super(parent, setting, offset);
      this.setting = (StringSetting)setting;
   }

   public void render(class_332 context, int mouseX, int mouseY, float delta) {
      super.render(context, mouseX, mouseY, delta);
      TextRenderer.drawString(String.valueOf(this.setting.getName()) + ": " + (this.setting.getValue().length() <= 9 ? this.setting.getValue() : this.setting.getValue().substring(0, 9) + "..."), context, this.parentX() + 9, this.parentY() + this.parentOffset() + this.offset + 9, (new Color(245, 245, 245, 255)).getRGB());
      if (!this.parent.parent.dragging) {
         int toHoverAlpha = this.isHovered((double)mouseX, (double)mouseY) ? 15 : 0;
         if (this.currentAlpha == null) {
            this.currentAlpha = new Color(255, 255, 255, toHoverAlpha);
         } else {
            this.currentAlpha = new Color(255, 255, 255, this.currentAlpha.getAlpha());
         }

         if (this.currentAlpha.getAlpha() != toHoverAlpha) {
            this.currentAlpha = ColorUtils.smoothAlphaTransition(0.05F, toHoverAlpha, this.currentAlpha);
         }

         context.method_25294(this.parentX(), this.parentY() + this.parentOffset() + this.offset, this.parentX() + this.parentWidth(), this.parentY() + this.parentOffset() + this.offset + this.parentHeight(), this.currentAlpha.getRGB());
      }

   }

   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isHovered(mouseX, mouseY) && button == 0) {
         this.mc.method_1507(new class_437(class_2561.method_43473()) {
            private String content;

            {
               this.content = StringBox.this.setting.getValue();
            }

            public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
               RenderUtils.unscaledProjection(context);
               mouseX *= class_310.method_1551().method_22683().method_4495();
               mouseY *= class_310.method_1551().method_22683().method_4495();
               super.method_25394(context, mouseX, mouseY, delta);
               context.method_25294(0, 0, StringBox.this.mc.method_22683().method_4480(), StringBox.this.mc.method_22683().method_4507(), (new Color(0, 0, 0, ClickGUI.background.getValue() ? 200 : 0)).getRGB());
               int screenMidX = StringBox.this.mc.method_22683().method_4480() / 2;
               int screenMidY = StringBox.this.mc.method_22683().method_4507() / 2;
               int contentWidth = Math.max(TextRenderer.getWidth(this.content), 600);
               int width = contentWidth + 30;
               int startX = screenMidX - width / 2;
               int startY = screenMidY - 30;
               RenderUtils.renderRoundedQuad(context, new Color(0, 0, 0, ClickGUI.alphaWindow.getValueInt()), (double)startX, (double)startY, (double)(startX + width), (double)(screenMidY + 30), (double)5.0F, (double)5.0F, (double)0.0F, (double)0.0F, (double)20.0F);
               TextRenderer.drawCenteredString(StringBox.this.setting.getName(), context, screenMidX, startY + 10, (new Color(245, 245, 245, 255)).getRGB());
               context.method_25294(startX, screenMidY, startX + width, screenMidY + 30, (new Color(0, 0, 0, 120)).getRGB());
               RenderUtils.renderRoundedOutline(context, new Color(50, 50, 50, 255), (double)(startX + 10), (double)(screenMidY + 5), (double)(startX + (width - 10)), (double)(screenMidY + 25), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)2.0F, (double)20.0F);
               TextRenderer.drawString(this.content, context, startX + 15, screenMidY + 8, (new Color(245, 245, 245, 255)).getRGB());
               context.method_25294(startX, screenMidY, startX + width, screenMidY + 1, Utils.getMainColor(255, 1).getRGB());
               RenderUtils.scaledProjection(context);
            }

            public boolean method_25404(class_11908 keyInput) {
               int keyCode = keyInput.comp_4795();
               int modifiers = keyInput.comp_4797();
               if (keyCode == 256) {
                  StringBox.this.setting.setValue(this.content.strip());
                  StringBox.this.mc.method_1507(Dqrkis.INSTANCE.clickGui);
                  return true;
               } else if (this.isPasteShortcut(keyInput)) {
                  String var10001 = this.content;
                  this.content = var10001 + StringBox.this.mc.field_1774.method_1460();
                  return true;
               } else if (this.isCopyShortcut(keyInput)) {
                  StringBox.this.mc.field_1774.method_1455(this.content);
                  return true;
               } else if (keyCode == 259) {
                  if (!this.content.isEmpty()) {
                     this.content = this.content.substring(0, this.content.length() - 1);
                  }

                  return true;
               } else {
                  return super.method_25404(keyInput);
               }
            }

            public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
            }

            public boolean method_25400(class_11905 charInput) {
               if (!charInput.method_74227()) {
                  return super.method_25400(charInput);
               } else {
                  String var10001 = this.content;
                  this.content = var10001 + charInput.method_74226();
                  return true;
               }
            }

            public boolean method_25422() {
               return false;
            }

            private boolean isCopyShortcut(class_11908 keyInput) {
               return keyInput.comp_4795() == 67 && (keyInput.comp_4797() & 2) != 0;
            }

            private boolean isPasteShortcut(class_11908 keyInput) {
               return keyInput.comp_4795() == 86 && (keyInput.comp_4797() & 2) != 0;
            }
         });
      }

      super.mouseClicked(mouseX, mouseY, button);
   }
}
