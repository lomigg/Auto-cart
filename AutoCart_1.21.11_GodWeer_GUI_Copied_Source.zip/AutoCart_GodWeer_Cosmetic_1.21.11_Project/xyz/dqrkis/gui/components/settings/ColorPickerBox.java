package xyz.dqrkis.gui.components.settings;

import java.awt.Color;
import net.minecraft.class_332;
import xyz.dqrkis.gui.components.ModuleButton;
import xyz.dqrkis.module.setting.ColorSetting;
import xyz.dqrkis.utils.TextRenderer;

public final class ColorPickerBox extends RenderableSetting {
   private final ColorSetting setting;
   private boolean pickingHue;

   public ColorPickerBox(ModuleButton parent, ColorSetting setting, int offset) {
      super(parent, setting, offset);
      this.setting = setting;
   }

   public int parentHeight() {
      return 18;
   }

   public void render(class_332 context, int mouseX, int mouseY, float delta) {
      super.render(context, mouseX, mouseY, delta);
      String label = this.setting.getName().toString();
      TextRenderer.drawString(label, context, this.parentX() + 4, this.parentY() + this.offset + 6, Color.WHITE.getRGB());
      int previewX = this.parentX() + this.parentWidth() - 42;
      int previewY = this.parentY() + this.offset + 3;
      int previewW = 34;
      int previewH = 12;
      context.method_25294(previewX, previewY, previewX + previewW, previewY + previewH, this.setting.getValue().getRGB());
      context.method_25294(previewX, previewY, previewX + previewW, previewY + 1, -16777216);
      context.method_25294(previewX, previewY + previewH - 1, previewX + previewW, previewY + previewH, -16777216);
      context.method_25294(previewX, previewY, previewX + 1, previewY + previewH, -16777216);
      context.method_25294(previewX + previewW - 1, previewY, previewX + previewW, previewY + previewH, -16777216);
      TextRenderer.drawString(this.setting.toHex(), context, previewX - 58, this.parentY() + this.offset + 6, (new Color(180, 180, 180)).getRGB());
   }

   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isHovered(mouseX, mouseY)) {
         if (button == 0) {
            float[] hsb = Color.RGBtoHSB(this.setting.getValue().getRed(), this.setting.getValue().getGreen(), this.setting.getValue().getBlue(), (float[])null);
            hsb[0] = (hsb[0] + 0.08F) % 1.0F;
            this.setting.setValue(Color.getHSBColor(hsb[0], hsb[1], hsb[2]));
         } else if (button == 1) {
            Color c = this.setting.getValue();
            int a = (c.getAlpha() + 64) % 256;
            this.setting.setValue(new Color(c.getRed(), c.getGreen(), c.getBlue(), a == 0 ? 255 : a));
         }

      }
   }
}
