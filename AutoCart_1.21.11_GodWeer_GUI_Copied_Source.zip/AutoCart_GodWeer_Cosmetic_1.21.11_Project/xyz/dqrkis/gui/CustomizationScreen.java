package xyz.dqrkis.gui;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.modules.cart.Cart;
import xyz.dqrkis.module.modules.cart.XbowCart;
import xyz.dqrkis.module.modules.client.ClickGUI;
import xyz.dqrkis.utils.RenderUtils;
import xyz.dqrkis.utils.TextRenderer;

/** GodWeer SwordReplacerScreen-style UI, ported without GodWeer dependencies. */
public final class CustomizationScreen extends class_437 {
    private static final int W = 670, H = 360, SIDEBAR = 128, GAP = 10, CARD_W = 146, CARD_H = 112;
    private int left, top, selectedTab, scroll;
    private String search = "";
    private boolean searching;
    private static final String[] TABS = {"Swords", "Head", "Back", "Models"};

    private static final Entry[] SWORDS = {
        new Entry("Abominable Blade", class_1802.field_8377), new Entry("Amethyst Shuriken", class_1802.field_8302),
        new Entry("Ancient Sword", class_1802.field_8377), new Entry("Acidic Cleaver", class_1802.field_8377),
        new Entry("Auto Cart", class_1802.field_8377), new Entry("Auto Cart bow", class_1802.field_8102),
        new Entry("Crossbow Cart", class_1802.field_8373), new Entry("Netherite Blade", class_1802.field_8377),
        new Entry("Diamond Blade", class_1802.field_8377)
    };
    private static final Entry[] HEAD = { new Entry("Cat Ears", class_1802.field_8165), new Entry("China Hat", class_1802.field_8165), new Entry("Cosmetic Head", class_1802.field_8165) };
    private static final Entry[] BACK = { new Entry("Wings", class_1802.field_8165), new Entry("Trail", class_1802.field_8165), new Entry("Jump Circle", class_1802.field_8165) };
    private static final Entry[] MODELS = {
        new Entry("Rabbit", class_1802.field_8165), new Entry("Chinchilla", class_1802.field_8165), new Entry("Crab", class_1802.field_8165),
        new Entry("Demon", class_1802.field_8165), new Entry("Freddy", class_1802.field_8165), new Entry("Jeff", class_1802.field_8165),
        new Entry("Sonic", class_1802.field_8165), new Entry("Amogus", class_1802.field_8165), new Entry("Cuphead", class_1802.field_8165)
    };

    private static final class Entry {
        final String name; final class_1799 stack;
        Entry(String name, class_1799 stack) { this.name = name; this.stack = new class_1799(stack.method_7968(), 1); }
    }

    public CustomizationScreen() { super(class_2561.method_43470("Customization")); }

    @Override protected void method_25426() {
        left = (field_22789 - W) / 2; top = (field_22790 - H) / 2; scroll = 0;
    }

    @Override public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, field_22789, field_22790, 0x66000000);
        RenderUtils.renderRoundedQuad(context, new Color(12,12,17,238), left, top, left+W, top+H, 12,12,12,12,30);
        RenderUtils.renderRoundedQuad(context, new Color(19,19,25,225), left+10, top+42, left+SIDEBAR-4, top+H-12, 8,8,8,8,20);
        TextRenderer.drawString("Customization", context, left+14, top+24, Color.WHITE.getRGB());
        int sx = left+W-205;
        RenderUtils.renderRoundedQuad(context, new Color(25,25,31,235), sx, top+12, left+W-12, top+39, 7,7,7,7,18);
        TextRenderer.drawString(search.isEmpty()?"Find sword...":search, context, sx+11, top+25, search.isEmpty()?0xff77777f:0xffeeeeee);
        context.method_25294(left+SIDEBAR, top+52, left+SIDEBAR+1, top+H-12, 0x22ffffff);
        for (int i=0;i<TABS.length;i++) {
            int y=top+54+i*45; boolean selected=i==selectedTab;
            if(selected) RenderUtils.renderRoundedQuad(context,new Color(117,35,205,235),left+16,y,left+SIDEBAR-18,y+35,6,6,6,6,18);
            TextRenderer.drawCenteredString(TABS[i],context,left+51,y+21,selected?Color.WHITE.getRGB():0xff7f7f86);
        }
        List<Entry> filtered = filtered();
        int contentX=left+SIDEBAR+14, contentY=top+58+scroll;
        for(int i=0;i<filtered.size();i++) {
            int x=contentX+(i%3)*(CARD_W+GAP), y=contentY+(i/3)*(CARD_H+GAP);
            if(y+CARD_H<top+48 || y>top+H-8) continue;
            boolean hovered=mouseX>=x&&mouseX<=x+CARD_W&&mouseY>=y&&mouseY<=y+CARD_H;
            RenderUtils.renderRoundedQuad(context,new Color(hovered?35:21,hovered?35:21,hovered?43:25,235),x,y,x+CARD_W,y+CARD_H,8,8,8,8,20);
            context.method_51427(filtered.get(i).stack,x+CARD_W/2-8,y+16);
            TextRenderer.drawCenteredString(filtered.get(i).name,context,x+CARD_W/2,y+91,0xffdddddf);
        }
    }

    private List<Entry> filtered() {
        Entry[] a=switch(selectedTab){case 1->HEAD;case 2->BACK;case 3->MODELS;default->SWORDS;};
        List<Entry> out=new ArrayList<>(); for(Entry e:a) if(search.isEmpty()||e.name.toLowerCase().contains(search.toLowerCase())) out.add(e); return out;
    }

    @Override public boolean method_25402(class_11909 click, boolean doubled) {
        double mx=click.comp_4798(), my=click.comp_4799(); int button=click.method_74245();
        if(button!=0) return true;
        if(mx>=left+W-205&&mx<=left+W-12&&my>=top+12&&my<=top+39){searching=true;return true;}
        for(int i=0;i<TABS.length;i++){int y=top+54+i*45;if(mx>=left+16&&mx<=left+SIDEBAR-18&&my>=y&&my<=y+35){selectedTab=i;scroll=0;return true;}}
        List<Entry> list=filtered(); int cx=left+SIDEBAR+14, cy=top+58+scroll;
        for(int i=0;i<list.size();i++){int x=cx+(i%3)*(CARD_W+GAP),y=cy+(i/3)*(CARD_H+GAP);if(mx>=x&&mx<=x+CARD_W&&my>=y&&my<=y+CARD_H){if("Auto Cart".equals(list.get(i).name))toggle(Cart.class);else if("Auto Cart bow".equals(list.get(i).name))toggle(XbowCart.class);return true;}}
        return true;
    }

    private <T extends Module> void toggle(Class<T> type){T m=Dqrkis.INSTANCE.getModuleManager().getModule(type);if(m!=null)m.toggle();}

    @Override public boolean method_25404(class_11908 keyInput){
        int key=keyInput.comp_4795(); if(key==256){close();return true;} if(searching&&key==259&&!search.isEmpty()){search=search.substring(0,search.length()-1);return true;} return true;
    }
    @Override public boolean method_25401(double mouseX,double mouseY,double horizontalAmount,double verticalAmount){
        scroll+=(int)(verticalAmount*18); int max=Math.max(0,((filtered().size()+2)/3)*(CARD_H+GAP)-(H-70)); if(scroll>0)scroll=0;if(scroll<-max)scroll=-max;return true;
    }
    @Override public boolean method_25410(char chr,int modifiers){if(searching&&!Character.isISOControl(chr)){search+=chr;return true;}return true;}
    private void close(){ClickGUI g=Dqrkis.INSTANCE.getModuleManager().getModule(ClickGUI.class);if(g!=null)g.setEnabledStatus(false);class_310.method_1551().method_29970(Dqrkis.INSTANCE.previousScreen);searching=false;}
    @Override public boolean method_25421(){return false;}
}
