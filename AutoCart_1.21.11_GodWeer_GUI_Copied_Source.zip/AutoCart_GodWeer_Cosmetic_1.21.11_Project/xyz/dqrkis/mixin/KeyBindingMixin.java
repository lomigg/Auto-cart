package xyz.dqrkis.mixin;

import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.imixin.IKeyBinding;

@Mixin({class_304.class})
public abstract class KeyBindingMixin implements IKeyBinding {
   @Shadow
   private class_3675.class_306 field_1655;

   public boolean isActuallyPressed() {
      int code = this.field_1655.method_1444();
      return class_3675.method_15987(Dqrkis.mc.method_22683(), code);
   }

   public void resetPressed() {
      this.method_23481(this.isActuallyPressed());
   }

   @Shadow
   public abstract void method_23481(boolean var1);
}
