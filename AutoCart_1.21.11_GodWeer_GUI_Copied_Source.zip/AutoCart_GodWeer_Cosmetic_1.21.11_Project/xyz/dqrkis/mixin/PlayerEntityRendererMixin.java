package xyz.dqrkis.mixin;

import net.minecraft.class_1007;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Cosmetic integration point for CatEars.
 *
 * The project compiles against Minecraft's Intermediary names, so this mixin
 * targets PlayerEntityRenderer through its 1.21.11 Intermediary class name.
 * The class is intentionally empty until a renderer feature is attached.
 */
@Mixin(class_1007.class)
public abstract class PlayerEntityRendererMixin {
}
