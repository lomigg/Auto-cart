package xyz.dqrkis.mixin;

import net.minecraft.class_1041;
import net.minecraft.class_310;
import net.minecraft.class_638;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.event.EventManager;
import xyz.dqrkis.event.events.AttackListener;
import xyz.dqrkis.event.events.BlockBreakingListener;
import xyz.dqrkis.event.events.ItemUseListener;
import xyz.dqrkis.event.events.ResolutionListener;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.utils.MouseSimulation;

@Mixin({class_310.class})
public class MinecraftClientMixin {
   @Shadow
   public @Nullable class_638 field_1687;
   @Shadow
   @Final
   private class_1041 field_1704;

   @Inject(
      method = {"method_1574"},
      at = {@At("HEAD")}
   )
   private void onTick(CallbackInfo ci) {
      if (this.field_1687 != null) {
         TickListener.TickEvent event = new TickListener.TickEvent();
         EventManager.fire(event);
      }

   }

   @Inject(
      method = {"method_15993"},
      at = {@At("HEAD")}
   )
   private void onResolutionChanged(CallbackInfo ci) {
      EventManager.fire(new ResolutionListener.ResolutionEvent(this.field_1704));
   }

   @Inject(
      method = {"method_1583"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onItemUse(CallbackInfo ci) {
      ItemUseListener.ItemUseEvent event = new ItemUseListener.ItemUseEvent();
      EventManager.fire(event);
      if (event.isCancelled()) {
         ci.cancel();
      }

      if (MouseSimulation.isMouseButtonPressed(1)) {
         MouseSimulation.mouseButtons.put(1, false);
         ci.cancel();
      }

   }

   @Inject(
      method = {"method_1536"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onAttack(CallbackInfoReturnable<Boolean> cir) {
      AttackListener.AttackEvent event = new AttackListener.AttackEvent();
      EventManager.fire(event);
      if (event.isCancelled()) {
         cir.setReturnValue(false);
      }

      if (MouseSimulation.isMouseButtonPressed(0)) {
         MouseSimulation.mouseButtons.put(0, false);
         cir.setReturnValue(false);
      }

   }

   @Inject(
      method = {"method_1590"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onBlockBreaking(boolean breaking, CallbackInfo ci) {
      BlockBreakingListener.BlockBreakingEvent event = new BlockBreakingListener.BlockBreakingEvent();
      EventManager.fire(event);
      if (event.isCancelled()) {
         ci.cancel();
      }

      if (MouseSimulation.isMouseButtonPressed(0)) {
         MouseSimulation.mouseButtons.put(0, false);
         ci.cancel();
      }

   }

   @Inject(
      method = {"method_1490"},
      at = {@At("HEAD")}
   )
   private void onClose(CallbackInfo ci) {
      Dqrkis.INSTANCE.getProfileManager().saveProfile();
   }
}
