package xyz.dqrkis.mixin;

import net.minecraft.class_310;
import net.minecraft.class_312;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.dqrkis.event.EventManager;
import xyz.dqrkis.event.events.ButtonListener;
import xyz.dqrkis.event.events.MouseMoveListener;
import xyz.dqrkis.event.events.MouseUpdateListener;

@Mixin({class_312.class})
public abstract class MouseMixin {
   @Shadow
   @Final
   private class_310 field_1779;
   @Unique
   private double dqrkis$lastMouseX;
   @Unique
   private double dqrkis$lastMouseY;
   @Unique
   private boolean dqrkis$initialized;
   @Unique
   private final int[] dqrkis$buttonStates = new int[8];

   @Shadow
   public abstract double method_1603();

   @Shadow
   public abstract double method_1604();

   @Inject(
      method = {"method_55793"},
      at = {@At("TAIL")}
   )
   private void onMouseUpdate(CallbackInfo ci) {
      EventManager.fire(new MouseUpdateListener.MouseUpdateEvent());
      long window = this.field_1779.method_22683().method_4490();
      double x = this.method_1603();
      double y = this.method_1604();
      if (!this.dqrkis$initialized) {
         this.dqrkis$initialized = true;
         this.dqrkis$lastMouseX = x;
         this.dqrkis$lastMouseY = y;

         for(int button = 0; button < this.dqrkis$buttonStates.length; ++button) {
            this.dqrkis$buttonStates[button] = GLFW.glfwGetMouseButton(window, button);
         }

      } else {
         if (x != this.dqrkis$lastMouseX || y != this.dqrkis$lastMouseY) {
            this.dqrkis$lastMouseX = x;
            this.dqrkis$lastMouseY = y;
            EventManager.fire(new MouseMoveListener.MouseMoveEvent(window, x, y));
         }

         for(int button = 0; button < this.dqrkis$buttonStates.length; ++button) {
            int state = GLFW.glfwGetMouseButton(window, button);
            if (state != this.dqrkis$buttonStates[button]) {
               this.dqrkis$buttonStates[button] = state;
               EventManager.fire(new ButtonListener.ButtonEvent(button, window, state));
            }
         }

      }
   }
}
