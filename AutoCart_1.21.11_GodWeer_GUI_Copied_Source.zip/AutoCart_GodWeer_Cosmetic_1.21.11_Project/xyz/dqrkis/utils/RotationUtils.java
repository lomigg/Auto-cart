package xyz.dqrkis.utils;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.utils.rotation.Rotation;

public final class RotationUtils {
   public static class_243 getEyesPos(class_1657 player) {
      return player.method_5836(RenderUtils.tickProgress());
   }

   public static class_2338 getCameraBlockPos() {
      return Dqrkis.mc.field_1773.method_19418().method_19328();
   }

   public static class_2338 getEyesBlockPos() {
      return new class_2338((int)getEyesPos(Dqrkis.mc.field_1724).field_1352, (int)getEyesPos(Dqrkis.mc.field_1724).field_1351, (int)getEyesPos(Dqrkis.mc.field_1724).field_1350);
   }

   public static class_243 getPlayerLookVec(float yaw, float pitch) {
      float f = pitch * ((float)Math.PI / 180F);
      float g = -yaw * ((float)Math.PI / 180F);
      float h = class_3532.method_15362((double)g);
      float i = class_3532.method_15374((double)g);
      float j = class_3532.method_15362((double)f);
      float k = class_3532.method_15374((double)f);
      return new class_243((double)(i * j), (double)(-k), (double)(h * j));
   }

   public static class_243 getPlayerLookVec(class_1657 player) {
      return getPlayerLookVec(player.method_36454(), player.method_36455());
   }

   public static Rotation getDiff(Rotation rotation1, Rotation rotation2) {
      double yaw = Math.abs(Math.max(rotation1.yaw(), rotation2.yaw()) - Math.min(rotation1.yaw(), rotation2.yaw()));
      double pitch = Math.abs(Math.max(rotation1.pitch(), rotation2.pitch()) - Math.min(rotation1.pitch(), rotation2.pitch()));
      return new Rotation(yaw, pitch);
   }

   public static Rotation getSmoothRotation(Rotation from, Rotation to, double speed) {
      return new Rotation((double)class_3532.method_17821((float)speed, (float)from.yaw(), (float)to.yaw()), (double)class_3532.method_17821((float)speed, (float)from.pitch(), (float)to.pitch()));
   }

   public static double getTotalDiff(Rotation rotation1, Rotation rotation2) {
      Rotation diff = getDiff(rotation1, rotation2);
      return diff.yaw() + diff.pitch();
   }

   public static class_243 getClientLookVec() {
      return getPlayerLookVec(Dqrkis.mc.field_1724);
   }

   public static Rotation getDirection(class_1297 entity, class_243 vec) {
      double dx = vec.field_1352 - entity.method_23317();
      double dy = vec.field_1351 - entity.method_23318();
      double dz = vec.field_1350 - entity.method_23321();
      double dist = (double)class_3532.method_15355((float)(dx * dx + dz * dz));
      return new Rotation(class_3532.method_15338(Math.toDegrees(Math.atan2(dz, dx)) - (double)90.0F), -class_3532.method_15338(Math.toDegrees(Math.atan2(dy, dist))));
   }

   public static double getAngleToRotation(Rotation rotation) {
      double currentYaw = (double)class_3532.method_15393(Dqrkis.mc.field_1724.method_36454());
      double currentPitch = (double)class_3532.method_15393(Dqrkis.mc.field_1724.method_36455());
      double diffYaw = class_3532.method_15338(currentYaw - rotation.yaw());
      double diffPitch = class_3532.method_15338(currentPitch - rotation.pitch());
      return Math.sqrt(diffYaw * diffYaw + diffPitch * diffPitch);
   }

   public static boolean isRotating() {
      return false;
   }

   public static void rotateTo(float yaw, float pitch, Runnable callback) {
      if (Dqrkis.mc.field_1724 != null) {
         Dqrkis.mc.field_1724.method_36456(yaw);
         Dqrkis.mc.field_1724.method_36457(pitch);
         if (callback != null) {
            callback.run();
         }
      }

   }
}
