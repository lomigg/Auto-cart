package xyz.dqrkis.utils;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import xyz.dqrkis.Dqrkis;

public final class CrystalUtils {
   public static boolean canPlaceCrystalClient(class_2338 block) {
      class_2680 blockState = Dqrkis.mc.field_1687.method_8320(block);
      return !blockState.method_27852(class_2246.field_10540) && !blockState.method_27852(class_2246.field_9987) ? false : canPlaceCrystalClientAssumeObsidian(block);
   }

   public static boolean canPlaceCrystalClientAssumeObsidian(class_2338 block) {
      class_2338 blockPos2 = block.method_10084();
      if (!Dqrkis.mc.field_1687.method_22347(blockPos2)) {
         return false;
      } else {
         double d = (double)blockPos2.method_10263();
         double e = (double)blockPos2.method_10264();
         double f = (double)blockPos2.method_10260();
         List<class_1297> list = Dqrkis.mc.field_1687.method_8335((class_1297)null, new class_238(d, e, f, d + (double)1.0F, e + (double)2.0F, f + (double)1.0F));
         return list.isEmpty();
      }
   }

   public static boolean canPlaceCrystalServer(class_2338 pos) {
      class_2680 blockState = Dqrkis.mc.field_1687.method_8320(pos);
      if (blockState.method_27852(class_2246.field_10540) && blockState.method_27852(class_2246.field_9987)) {
         class_2338 blockPos = pos.method_10084();
         if (!Dqrkis.mc.field_1687.method_22347(blockPos)) {
            return false;
         } else {
            double d = (double)blockPos.method_10263();
            double e = (double)blockPos.method_10264();
            double f = (double)blockPos.method_10260();
            List<class_1297> list = Dqrkis.mc.field_1687.method_8335((class_1297)null, new class_238(d, e, f, d + (double)1.0F, e + (double)2.0F, f + (double)1.0F));
            return list.isEmpty();
         }
      } else {
         return false;
      }
   }
}
