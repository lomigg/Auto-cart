package xyz.dqrkis.utils;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class DiscordWebhook {
   private final String url;
   private final List<Path> attachments = new ArrayList();
   private String title;
   private String description;

   public DiscordWebhook(String url) {
      this.url = url;
   }

   public DiscordWebhook title(String title) {
      this.title = title;
      return this;
   }

   public DiscordWebhook description(String description) {
      this.description = description;
      return this;
   }

   public DiscordWebhook attach(Path file) {
      this.attachments.add(file);
      return this;
   }

   private String buildPayloadJson() {
      StringBuilder sb = new StringBuilder("{\"embeds\":[{");
      if (this.title != null) {
         sb.append("\"title\":").append(DiscordWebhook.Json.quote(this.title));
      }

      if (this.description != null) {
         if (!sb.isEmpty() && sb.charAt(sb.length() - 1) != '{') {
            sb.append(',');
         }

         sb.append("\"description\":").append(DiscordWebhook.Json.quote(this.description));
      }

      sb.append("}]}");
      return sb.toString();
   }

   public void sendAsync() {
      Thread.ofVirtual().start(this::sendBlocking);
   }

   public void sendBlocking() {
      try {
         String boundary = "----DqrkisBoundary" + System.nanoTime();
         ArrayList<byte[]> byteArrays = new ArrayList();
         byteArrays.add(multipartField(boundary, "payload_json", this.buildPayloadJson()));

         for(Path file : this.attachments) {
            if (Files.exists(file, new LinkOption[0])) {
               byteArrays.add(multipartFileHeader(boundary, file.getFileName().toString()));
               byteArrays.add(Files.readAllBytes(file));
               byteArrays.add("\r\n".getBytes());
            }
         }

         byteArrays.add(("--" + boundary + "--\r\n").getBytes());
         HttpRequest.BodyPublisher requestBody = BodyPublishers.ofByteArrays(byteArrays);
         HttpRequest request = HttpRequest.newBuilder().uri(URI.create(this.url)).header("Content-Type", "multipart/form-data; boundary=" + boundary).POST(requestBody).build();
         HttpClient.newHttpClient().send(request, BodyHandlers.discarding());
      } catch (InterruptedException | IOException var5) {
      }

   }

   private static byte[] multipartField(String boundary, String name, String value) {
      return ("--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name + "\"\r\n\r\n" + value + "\r\n").getBytes();
   }

   private static byte[] multipartFileHeader(String boundary, String fileName) {
      return ("--" + boundary + "\r\nContent-Disposition: form-data; name=\"files[]\"; filename=\"" + fileName + "\"\r\nContent-Type: image/png\r\n\r\n").getBytes();
   }

   private static final class Json {
      static String quote(String s) {
         String var10000 = s.replace("\\", "\\\\");
         return "\"" + var10000.replace("\"", "\\\"") + "\"";
      }
   }
}
