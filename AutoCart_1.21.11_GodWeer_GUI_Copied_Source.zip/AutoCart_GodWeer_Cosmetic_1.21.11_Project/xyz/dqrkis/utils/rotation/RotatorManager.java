package xyz.dqrkis.utils.rotation;

import net.minecraft.class_2596;
import net.minecraft.class_2708;
import net.minecraft.class_2828;
import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.event.EventManager;
import xyz.dqrkis.event.events.AttackListener;
import xyz.dqrkis.event.events.BlockBreakingListener;
import xyz.dqrkis.event.events.ItemUseListener;
import xyz.dqrkis.event.events.MovementPacketListener;
import xyz.dqrkis.event.events.PacketReceiveListener;
import xyz.dqrkis.event.events.PacketSendListener;
import xyz.dqrkis.utils.RotationUtils;

public final class RotatorManager implements PacketSendListener, BlockBreakingListener, ItemUseListener, AttackListener, MovementPacketListener, PacketReceiveListener {
   private boolean enabled;
   private boolean rotateBack;
   private boolean resetRotation;
   private final EventManager eventManager;
   private Rotation currentRotation;
   private float clientYaw;
   private float clientPitch;
   private float serverYaw;
   private float serverPitch;
   private boolean wasDisabled;

   public RotatorManager() {
      this.eventManager = Dqrkis.INSTANCE.eventManager;
      this.eventManager.remove(PacketSendListener.class, this);
      this.eventManager.remove(AttackListener.class, this);
      this.eventManager.remove(ItemUseListener.class, this);
      this.eventManager.remove(MovementPacketListener.class, this);
      this.eventManager.remove(PacketReceiveListener.class, this);
      this.eventManager.remove(BlockBreakingListener.class, this);
      this.enabled = true;
      this.rotateBack = false;
      this.resetRotation = false;
      this.serverYaw = 0.0F;
      this.serverPitch = 0.0F;
      this.clientYaw = 0.0F;
      this.clientPitch = 0.0F;
   }

   public void shutDown() {
      this.eventManager.remove(PacketSendListener.class, this);
      this.eventManager.remove(AttackListener.class, this);
      this.eventManager.remove(ItemUseListener.class, this);
      this.eventManager.remove(MovementPacketListener.class, this);
      this.eventManager.remove(PacketReceiveListener.class, this);
      this.eventManager.remove(BlockBreakingListener.class, this);
   }

   public Rotation getServerRotation() {
      return new Rotation((double)this.serverYaw, (double)this.serverPitch);
   }

   public void enable() {
      this.enabled = true;
      this.rotateBack = false;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void disable() {
      if (this.isEnabled()) {
         this.enabled = false;
         if (!this.rotateBack) {
            this.rotateBack = true;
         }
      }

   }

   public void setRotation(Rotation rotation) {
      this.currentRotation = rotation;
   }

   public void setRotation(double yaw, double pitch) {
      this.setRotation(new Rotation(yaw, pitch));
   }

   private void resetClientRotation() {
      Dqrkis.mc.field_1724.method_36456(this.clientYaw);
      Dqrkis.mc.field_1724.method_36457(this.clientPitch);
      this.resetRotation = false;
   }

   public void setClientRotation(Rotation rotation) {
      this.clientYaw = Dqrkis.mc.field_1724.method_36454();
      this.clientPitch = Dqrkis.mc.field_1724.method_36455();
      Dqrkis.mc.field_1724.method_36456((float)rotation.yaw());
      Dqrkis.mc.field_1724.method_36457((float)rotation.pitch());
      this.resetRotation = true;
   }

   public void setServerRotation(Rotation rotation) {
      this.serverYaw = (float)rotation.yaw();
      this.serverPitch = (float)rotation.pitch();
   }

   public void onAttack(AttackListener.AttackEvent event) {
      if (!this.isEnabled() && this.wasDisabled) {
         this.enabled = true;
         this.wasDisabled = false;
      }

   }

   public void onItemUse(ItemUseListener.ItemUseEvent event) {
      if (!event.isCancelled() && this.isEnabled()) {
         this.enabled = false;
         this.wasDisabled = true;
      }

   }

   public void onPacketSend(PacketSendListener.PacketSendEvent event) {
      class_2596 var3 = event.packet;
      if (var3 instanceof class_2828 packet) {
         this.serverYaw = packet.method_12271(this.serverYaw);
         this.serverPitch = packet.method_12270(this.serverPitch);
      }

   }

   public void onBlockBreaking(BlockBreakingListener.BlockBreakingEvent event) {
      if (!event.isCancelled() && this.isEnabled()) {
         this.enabled = false;
         this.wasDisabled = true;
      }

   }

   public void onSendMovementPackets() {
      if (this.isEnabled() && this.currentRotation != null) {
         this.setClientRotation(this.currentRotation);
         this.setServerRotation(this.currentRotation);
      } else {
         if (this.rotateBack) {
            Rotation serverRot = new Rotation((double)this.serverYaw, (double)this.serverPitch);
            Rotation clientRot = new Rotation((double)Dqrkis.mc.field_1724.method_36454(), (double)Dqrkis.mc.field_1724.method_36455());
            if (RotationUtils.getTotalDiff(serverRot, clientRot) > (double)1.0F) {
               Rotation smoothRotation = RotationUtils.getSmoothRotation(serverRot, clientRot, 0.2);
               this.setClientRotation(smoothRotation);
               this.setServerRotation(smoothRotation);
            } else {
               this.rotateBack = false;
            }
         }

      }
   }

   public void onPacketReceive(PacketReceiveListener.PacketReceiveEvent event) {
      class_2596 var3 = event.packet;
      if (var3 instanceof class_2708 packet) {
         this.serverYaw = packet.comp_3228().comp_3150();
         this.serverPitch = packet.comp_3228().comp_3151();
      }

   }
}
