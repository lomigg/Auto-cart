package xyz.dqrkis.utils;

import java.util.function.BiFunction;
import net.minecraft.class_1280;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1934;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5134;
import net.minecraft.class_640;
import net.minecraft.class_239.class_240;
import net.minecraft.class_2902.class_2903;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import xyz.dqrkis.Dqrkis;

public class DamageUtils {
   public static final RaycastFactory HIT_FACTORY = (context, blockPos) -> {
      class_2680 blockState = Dqrkis.mc.field_1687.method_8320(blockPos);
      return blockState.method_26204().method_9520() < 600.0F ? null : blockState.method_26220(Dqrkis.mc.field_1687, blockPos).method_1092(context.start(), context.end(), blockPos);
   };

   private DamageUtils() {
   }

   public static float crystalDamage(class_1309 target, class_243 targetPos, class_238 targetBox, class_243 explosionPos, RaycastFactory raycastFactory) {
      return explosionDamage(target, targetPos, targetBox, explosionPos, 12.0F, raycastFactory);
   }

   public static float bedDamage(class_1309 target, class_243 targetPos, class_238 targetBox, class_243 explosionPos, RaycastFactory raycastFactory) {
      return explosionDamage(target, targetPos, targetBox, explosionPos, 10.0F, raycastFactory);
   }

   public static float anchorDamage(class_1309 target, class_243 targetPos, class_238 targetBox, class_243 explosionPos, RaycastFactory raycastFactory) {
      return explosionDamage(target, targetPos, targetBox, explosionPos, 10.0F, raycastFactory);
   }

   public static float explosionDamage(class_1309 target, class_243 targetPos, class_238 targetBox, class_243 explosionPos, float power, RaycastFactory raycastFactory) {
      double modDistance = distance(targetPos.field_1352, targetPos.field_1351, targetPos.field_1350, explosionPos.field_1352, explosionPos.field_1351, explosionPos.field_1350);
      if (modDistance > (double)power) {
         return 0.0F;
      } else {
         double exposure = (double)getExposure(explosionPos, targetBox, raycastFactory);
         double impact = ((double)1.0F - modDistance / (double)power) * exposure;
         float damage = (float)((int)((impact * impact + impact) / (double)2.0F * (double)7.0F * (double)12.0F + (double)1.0F));
         return calculateReductions(damage, target, Dqrkis.mc.field_1687.method_48963().method_48807((class_1927)null));
      }
   }

   public static double distance(double x1, double y1, double z1, double x2, double y2, double z2) {
      return Math.sqrt(squaredDistance(x1, y1, z1, x2, y2, z2));
   }

   public static double distanceTo(class_1297 entity) {
      return distanceTo(entity.method_23317(), entity.method_23318(), entity.method_23321());
   }

   public static double distanceTo(class_2338 blockPos) {
      return distanceTo((double)blockPos.method_10263(), (double)blockPos.method_10264(), (double)blockPos.method_10260());
   }

   public static double distanceTo(class_243 vec3d) {
      return distanceTo(vec3d.method_10216(), vec3d.method_10214(), vec3d.method_10215());
   }

   public static double distanceTo(double x, double y, double z) {
      return Math.sqrt(squaredDistanceTo(x, y, z));
   }

   public static double squaredDistanceTo(class_1297 entity) {
      return squaredDistanceTo(entity.method_23317(), entity.method_23318(), entity.method_23321());
   }

   public static double squaredDistanceTo(class_2338 blockPos) {
      return squaredDistanceTo((double)blockPos.method_10263(), (double)blockPos.method_10264(), (double)blockPos.method_10260());
   }

   public static double squaredDistanceTo(double x, double y, double z) {
      return squaredDistance(Dqrkis.mc.field_1724.method_23317(), Dqrkis.mc.field_1724.method_23318(), Dqrkis.mc.field_1724.method_23321(), x, y, z);
   }

   public static double squaredDistance(double x1, double y1, double z1, double x2, double y2, double z2) {
      double f = x1 - x2;
      double g = y1 - y2;
      double h = z1 - z2;
      return org.joml.Math.fma(f, f, org.joml.Math.fma(g, g, h * h));
   }

   public static float crystalDamage(class_1309 target, class_243 crystal, boolean predictMovement, class_2338 obsidianPos) {
      return overridingExplosionDamage(target, crystal, 12.0F, predictMovement, obsidianPos, class_2246.field_10540.method_9564());
   }

   public static float crystalDamage(class_1309 target, class_243 crystal) {
      return explosionDamage(target, crystal, 12.0F, false);
   }

   public static float bedDamage(class_1309 target, class_243 bed) {
      return explosionDamage(target, bed, 10.0F, false);
   }

   public static float anchorDamage(class_1309 target, class_243 anchor) {
      return overridingExplosionDamage(target, anchor, 10.0F, false, class_2338.method_49638(anchor), class_2246.field_10124.method_9564());
   }

   private static float overridingExplosionDamage(class_1309 target, class_243 explosionPos, float power, boolean predictMovement, class_2338 overridePos, class_2680 overrideState) {
      return explosionDamage(target, explosionPos, power, predictMovement, getOverridingHitFactory(overridePos, overrideState));
   }

   private static float explosionDamage(class_1309 target, class_243 explosionPos, float power, boolean predictMovement) {
      return explosionDamage(target, explosionPos, power, predictMovement, HIT_FACTORY);
   }

   public static class_1934 getGameMode(class_1657 player) {
      class_640 playerListEntry = Dqrkis.mc.method_1562().method_2871(player.method_5667());
      return playerListEntry == null ? class_1934.field_9219 : playerListEntry.method_2958();
   }

   private static float explosionDamage(class_1309 target, class_243 explosionPos, float power, boolean predictMovement, RaycastFactory raycastFactory) {
      if (target == null) {
         return 0.0F;
      } else {
         if (target instanceof class_1657) {
            class_1657 player = (class_1657)target;
            if (getGameMode(player) == class_1934.field_9220) {
               return 0.0F;
            }
         }

         class_243 position = predictMovement ? target.method_73189().method_1019(target.method_18798()) : target.method_73189();
         class_238 box = target.method_5829();
         if (predictMovement) {
            box = box.method_997(target.method_18798());
         }

         return explosionDamage(target, position, box, explosionPos, power, raycastFactory);
      }
   }

   public static RaycastFactory getOverridingHitFactory(class_2338 overridePos, class_2680 overrideState) {
      return (context, blockPos) -> {
         class_2680 blockState;
         if (blockPos.equals(overridePos)) {
            blockState = overrideState;
         } else {
            blockState = Dqrkis.mc.field_1687.method_8320(blockPos);
            if (blockState.method_26204().method_9520() < 600.0F) {
               return null;
            }
         }

         return blockState.method_26220(Dqrkis.mc.field_1687, blockPos).method_1092(context.start(), context.end(), blockPos);
      };
   }

   public static float getAttackDamage(class_1309 attacker, class_1309 target) {
      float itemDamage = (float)attacker.method_45325(class_5134.field_23721);
      class_1282 var10000;
      if (attacker instanceof class_1657 player) {
         var10000 = Dqrkis.mc.field_1687.method_48963().method_48802(player);
      } else {
         var10000 = Dqrkis.mc.field_1687.method_48963().method_48812(attacker);
      }

      class_1282 damageSource = var10000;
      class_1799 stack = attacker.method_59958();
      float enchantDamage = 0.0F;
      if (attacker instanceof class_1657 playerEntity) {
         float charge = playerEntity.method_7261(0.5F);
         itemDamage *= 0.2F + charge * charge * 0.8F;
         enchantDamage *= charge;
         if (charge > 0.9F && attacker.field_6017 > (double)0.0F && !attacker.method_24828() && !attacker.method_6101() && !attacker.method_5799() && !attacker.method_6059(class_1294.field_5919) && !attacker.method_5765()) {
            itemDamage *= 1.5F;
         }
      }

      float damage = itemDamage + enchantDamage;
      damage = calculateReductions(damage, target, damageSource);
      return damage;
   }

   public static float fallDamage(class_1309 entity) {
      if (entity instanceof class_1657 player) {
         if (player.method_31549().field_7479) {
            return 0.0F;
         }
      }

      if (!entity.method_6059(class_1294.field_5906) && !entity.method_6059(class_1294.field_5902)) {
         int surface = Dqrkis.mc.field_1687.method_8500(entity.method_24515()).method_12032(class_2903.field_13197).method_12603(entity.method_31477() & 15, entity.method_31479() & 15);
         if (entity.method_31478() >= surface) {
            return fallDamageReductions(entity, surface);
         } else {
            class_3965 raycastResult = Dqrkis.mc.field_1687.method_17742(new class_3959(entity.method_73189(), new class_243(entity.method_23317(), (double)Dqrkis.mc.field_1687.method_31607(), entity.method_23321()), class_3960.field_17558, class_242.field_36338, entity));
            return raycastResult.method_17783() == class_240.field_1333 ? 0.0F : fallDamageReductions(entity, raycastResult.method_17777().method_10264());
         }
      } else {
         return 0.0F;
      }
   }

   private static float fallDamageReductions(class_1309 entity, int surface) {
      int fallHeight = (int)(entity.method_23318() - (double)surface + entity.field_6017 - (double)3.0F);
      class_1293 jumpBoostInstance = entity.method_6112(class_1294.field_5913);
      if (jumpBoostInstance != null) {
         fallHeight -= jumpBoostInstance.method_5578() + 1;
      }

      return calculateReductions((float)fallHeight, entity, Dqrkis.mc.field_1687.method_48963().method_48827());
   }

   public static float calculateReductions(float damage, class_1309 entity, class_1282 damageSource) {
      if (damageSource.method_5514()) {
         switch (Dqrkis.mc.field_1687.method_8407()) {
            case field_5805 -> damage = Math.min(damage / 2.0F + 1.0F, damage);
            case field_5807 -> damage *= 1.5F;
         }
      }

      damage = class_1280.method_5496(entity, damage, damageSource, getArmor(entity), (float)entity.method_45325(class_5134.field_23725));
      damage = resistanceReduction(entity, damage);
      damage = protectionReduction(entity, damage, damageSource);
      return Math.max(damage, 0.0F);
   }

   private static float getArmor(class_1309 entity) {
      return (float)Math.floor(entity.method_45325(class_5134.field_23724));
   }

   private static float protectionReduction(class_1309 player, float damage, class_1282 source) {
      return class_1280.method_5497(damage, 0.0F);
   }

   private static float resistanceReduction(class_1309 player, float damage) {
      class_1293 resistance = player.method_6112(class_1294.field_5907);
      if (resistance != null) {
         int lvl = resistance.method_5578() + 1;
         damage *= 1.0F - (float)lvl * 0.2F;
      }

      return Math.max(damage, 0.0F);
   }

   private static float getExposure(class_243 source, class_238 box, RaycastFactory raycastFactory) {
      double xDiff = box.field_1320 - box.field_1323;
      double yDiff = box.field_1325 - box.field_1322;
      double zDiff = box.field_1324 - box.field_1321;
      double xStep = (double)1.0F / (xDiff * (double)2.0F + (double)1.0F);
      double yStep = (double)1.0F / (yDiff * (double)2.0F + (double)1.0F);
      double zStep = (double)1.0F / (zDiff * (double)2.0F + (double)1.0F);
      if (xStep > (double)0.0F && yStep > (double)0.0F && zStep > (double)0.0F) {
         int misses = 0;
         int hits = 0;
         double xOffset = ((double)1.0F - Math.floor((double)1.0F / xStep) * xStep) * (double)0.5F;
         double zOffset = ((double)1.0F - Math.floor((double)1.0F / zStep) * zStep) * (double)0.5F;
         xStep *= xDiff;
         yStep *= yDiff;
         zStep *= zDiff;
         double startX = box.field_1323 + xOffset;
         double startY = box.field_1322;
         double startZ = box.field_1321 + zOffset;
         double endX = box.field_1320 + xOffset;
         double endY = box.field_1325;
         double endZ = box.field_1324 + zOffset;

         for(double x = startX; x <= endX; x += xStep) {
            for(double y = startY; y <= endY; y += yStep) {
               for(double z = startZ; z <= endZ; z += zStep) {
                  class_243 position = new class_243(x, y, z);
                  if (raycast(new ExposureRaycastContext(position, source), raycastFactory) == null) {
                     ++misses;
                  }

                  ++hits;
               }
            }
         }

         return (float)misses / (float)hits;
      } else {
         return 0.0F;
      }
   }

   private static class_3965 raycast(ExposureRaycastContext context, RaycastFactory raycastFactory) {
      return (class_3965)class_1922.method_17744(context.start, context.end, context, raycastFactory, (ctx) -> null);
   }

   public static record ExposureRaycastContext(class_243 start, class_243 end) {
   }

   @FunctionalInterface
   public interface RaycastFactory extends BiFunction<ExposureRaycastContext, class_2338, class_3965> {
   }
}
