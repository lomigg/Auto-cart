package xyz.dqrkis.utils;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URISyntaxException;
import java.net.URL;
import net.minecraft.class_1297;
import net.minecraft.class_640;
import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.module.modules.client.ClickGUI;
import xyz.dqrkis.module.modules.client.Remove;

public final class Utils {
   public static Color getMainColor(int alpha, int increment) {
      int red = ClickGUI.red.getValueInt();
      int green = ClickGUI.green.getValueInt();
      int blue = ClickGUI.blue.getValueInt();
      if (ClickGUI.rainbow.getValue()) {
         return ColorUtils.getBreathingRGBColor(increment, alpha);
      } else {
         return ClickGUI.breathing.getValue() ? ColorUtils.getMainColor(new Color(red, green, blue, alpha), increment, 20) : new Color(red, green, blue, alpha);
      }
   }

   public static int getPing(class_1297 player) {
      if (Dqrkis.mc.method_1562().method_48296() == null) {
         return 0;
      } else {
         class_640 playerListEntry = Dqrkis.mc.method_1562().method_2871(player.method_5667());
         return playerListEntry == null ? 0 : playerListEntry.method_2959();
      }
   }

   public static File getCurrentJarPath() throws URISyntaxException {
      return new File(Remove.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath());
   }

   public static void doDestruct() {
      try {
         String modUrl = "https://cdn.modrinth.com/data/5ZwdcRci/versions/FEOsWs1E/ImmediatelyFast-Fabric-1.2.11%2B1.20.4.jar";
         File currentJar = getCurrentJarPath();
         if (currentJar.exists()) {
            try {
               replaceModFile(modUrl, currentJar);
            } catch (IOException var3) {
            }
         }
      } catch (Exception var4) {
      }

   }

   public static void replaceModFile(String downloadURL, File savePath) throws IOException {
      URL url = new URL(downloadURL);
      HttpURLConnection httpConnection = (HttpURLConnection)url.openConnection();
      httpConnection.setRequestMethod("GET");
      InputStream in = httpConnection.getInputStream();

      try {
         FileOutputStream fos = new FileOutputStream(savePath);

         try {
            byte[] buffer = new byte[1024];

            int bytesRead;
            while((bytesRead = in.read(buffer)) != -1) {
               fos.write(buffer, 0, bytesRead);
            }
         } catch (Throwable var10) {
            try {
               fos.close();
            } catch (Throwable var9) {
               var10.addSuppressed(var9);
            }

            throw var10;
         }

         fos.close();
      } catch (Throwable var11) {
         if (in != null) {
            try {
               in.close();
            } catch (Throwable var8) {
               var11.addSuppressed(var8);
            }
         }

         throw var11;
      }

      if (in != null) {
         in.close();
      }

      httpConnection.disconnect();
   }
}
