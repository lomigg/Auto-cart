package xyz.dqrkis.event.events;

import java.util.ArrayList;
import net.minecraft.class_332;
import xyz.dqrkis.event.Event;
import xyz.dqrkis.event.Listener;

public interface HudListener extends Listener {
   void onRenderHud(HudEvent var1);

   public static class HudEvent extends Event<HudListener> {
      public class_332 context;
      public float delta;

      public HudEvent(class_332 context, float delta) {
         this.context = context;
         this.delta = delta;
      }

      public void fire(ArrayList<HudListener> listeners) {
         listeners.forEach((e) -> e.onRenderHud(this));
      }

      public Class<HudListener> getListenerType() {
         return HudListener.class;
      }
   }
}
