package xyz.dqrkis.event.events;

import java.util.ArrayList;
import net.minecraft.class_2596;
import xyz.dqrkis.event.CancellableEvent;
import xyz.dqrkis.event.Listener;

public interface PacketSendListener extends Listener {
   void onPacketSend(PacketSendEvent var1);

   public static class PacketSendEvent extends CancellableEvent<PacketSendListener> {
      public class_2596 packet;

      public PacketSendEvent(class_2596 packet) {
         this.packet = packet;
      }

      public void fire(ArrayList<PacketSendListener> listeners) {
         listeners.forEach((e) -> e.onPacketSend(this));
      }

      public Class<PacketSendListener> getListenerType() {
         return PacketSendListener.class;
      }
   }
}
