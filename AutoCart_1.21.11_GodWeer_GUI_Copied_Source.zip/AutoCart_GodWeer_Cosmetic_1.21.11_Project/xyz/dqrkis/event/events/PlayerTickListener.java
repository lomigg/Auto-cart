package xyz.dqrkis.event.events;

import java.util.ArrayList;
import xyz.dqrkis.event.Event;
import xyz.dqrkis.event.Listener;

public interface PlayerTickListener extends Listener {
   void onPlayerTick();

   public static class PlayerTickEvent extends Event<PlayerTickListener> {
      public void fire(ArrayList<PlayerTickListener> listeners) {
         listeners.forEach(PlayerTickListener::onPlayerTick);
      }

      public Class<PlayerTickListener> getListenerType() {
         return PlayerTickListener.class;
      }
   }
}
