package xyz.dqrkis.event.events;

import java.util.ArrayList;
import xyz.dqrkis.event.CancellableEvent;
import xyz.dqrkis.event.Listener;

public interface ItemUseListener extends Listener {
   void onItemUse(ItemUseEvent var1);

   public static class ItemUseEvent extends CancellableEvent<ItemUseListener> {
      public void fire(ArrayList<ItemUseListener> listeners) {
         listeners.forEach((e) -> e.onItemUse(this));
      }

      public Class<ItemUseListener> getListenerType() {
         return ItemUseListener.class;
      }
   }
}
