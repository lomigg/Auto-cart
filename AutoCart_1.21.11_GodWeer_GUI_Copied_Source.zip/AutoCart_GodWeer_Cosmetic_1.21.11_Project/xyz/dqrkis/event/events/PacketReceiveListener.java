package xyz.dqrkis.event.events;

import java.util.ArrayList;
import net.minecraft.class_2596;
import xyz.dqrkis.event.CancellableEvent;
import xyz.dqrkis.event.Listener;

public interface PacketReceiveListener extends Listener {
   void onPacketReceive(PacketReceiveEvent var1);

   public static class PacketReceiveEvent extends CancellableEvent<PacketReceiveListener> {
      public class_2596 packet;

      public PacketReceiveEvent(class_2596 packet) {
         this.packet = packet;
      }

      public void fire(ArrayList<PacketReceiveListener> listeners) {
         listeners.forEach((e) -> e.onPacketReceive(this));
      }

      public Class<PacketReceiveListener> getListenerType() {
         return PacketReceiveListener.class;
      }
   }
}
