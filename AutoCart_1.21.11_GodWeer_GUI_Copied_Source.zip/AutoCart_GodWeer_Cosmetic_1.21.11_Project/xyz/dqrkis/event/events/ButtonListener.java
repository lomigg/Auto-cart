package xyz.dqrkis.event.events;

import java.util.ArrayList;
import xyz.dqrkis.event.Event;
import xyz.dqrkis.event.Listener;

public interface ButtonListener extends Listener {
   void onButtonPress(ButtonEvent var1);

   public static class ButtonEvent extends Event<ButtonListener> {
      public int button;
      public int action;
      public long window;

      public ButtonEvent(int button, long window, int action) {
         this.button = button;
         this.window = window;
         this.action = action;
      }

      public void fire(ArrayList<ButtonListener> listeners) {
         listeners.forEach((e) -> e.onButtonPress(this));
      }

      public Class<ButtonListener> getListenerType() {
         return ButtonListener.class;
      }
   }
}
