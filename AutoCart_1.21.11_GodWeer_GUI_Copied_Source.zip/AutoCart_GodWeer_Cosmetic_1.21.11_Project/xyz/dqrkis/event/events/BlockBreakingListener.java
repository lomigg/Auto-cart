package xyz.dqrkis.event.events;

import java.util.ArrayList;
import xyz.dqrkis.event.CancellableEvent;
import xyz.dqrkis.event.Listener;

public interface BlockBreakingListener extends Listener {
   void onBlockBreaking(BlockBreakingEvent var1);

   public static class BlockBreakingEvent extends CancellableEvent<BlockBreakingListener> {
      public void fire(ArrayList<BlockBreakingListener> listeners) {
         listeners.forEach((e) -> e.onBlockBreaking(this));
      }

      public Class<BlockBreakingListener> getListenerType() {
         return BlockBreakingListener.class;
      }
   }
}
