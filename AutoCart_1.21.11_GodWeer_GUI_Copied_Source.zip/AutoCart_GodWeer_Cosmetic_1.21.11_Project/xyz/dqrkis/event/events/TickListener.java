package xyz.dqrkis.event.events;

import java.util.ArrayList;
import xyz.dqrkis.event.Event;
import xyz.dqrkis.event.Listener;

public interface TickListener extends Listener {
   void onTick();

   public static class TickEvent extends Event<TickListener> {
      public void fire(ArrayList<TickListener> listeners) {
         listeners.forEach(TickListener::onTick);
      }

      public Class<TickListener> getListenerType() {
         return TickListener.class;
      }
   }
}
