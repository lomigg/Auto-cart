package xyz.dqrkis.event.events;

import java.util.ArrayList;
import xyz.dqrkis.event.Event;
import xyz.dqrkis.event.Listener;

public interface ShieldDisabledListener extends Listener {
   void onShieldDisabled();

   public static class ShieldDisabledEvent extends Event<ShieldDisabledListener> {
      public void fire(ArrayList<ShieldDisabledListener> listeners) {
         listeners.forEach(ShieldDisabledListener::onShieldDisabled);
      }

      public Class<ShieldDisabledListener> getListenerType() {
         return ShieldDisabledListener.class;
      }
   }
}
