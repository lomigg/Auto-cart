package xyz.dqrkis.event.events;

import java.util.ArrayList;
import xyz.dqrkis.event.CancellableEvent;
import xyz.dqrkis.event.Listener;

public interface AttackListener extends Listener {
   void onAttack(AttackEvent var1);

   public static class AttackEvent extends CancellableEvent<AttackListener> {
      public void fire(ArrayList<AttackListener> listeners) {
         listeners.forEach((e) -> e.onAttack(this));
      }

      public Class<AttackListener> getListenerType() {
         return AttackListener.class;
      }
   }
}
