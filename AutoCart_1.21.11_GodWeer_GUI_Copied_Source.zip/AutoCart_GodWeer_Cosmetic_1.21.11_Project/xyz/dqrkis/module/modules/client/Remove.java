package xyz.dqrkis.module.modules.client;

import com.sun.jna.Memory;
import java.io.File;
import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.gui.ClickGui;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.Setting;
import xyz.dqrkis.module.setting.StringSetting;
import xyz.dqrkis.utils.EncryptedString;
import xyz.dqrkis.utils.Utils;

public final class Remove extends Module {
   public static boolean destruct = false;
   private final BooleanSetting replaceMod = (BooleanSetting)(new BooleanSetting(EncryptedString.of("phucnguyen_"), true)).setDescription(EncryptedString.of("phucnguyen_"));
   private final BooleanSetting saveLastModified = (BooleanSetting)(new BooleanSetting(EncryptedString.of("phucnguyen_"), true)).setDescription(EncryptedString.of("phucnguyen_"));
   private final StringSetting downloadURL = new StringSetting(EncryptedString.of("Replace URL"), "https://cdn.modrinth.com/data/c7m1mi73/versions/XsMMpmvW/packetfixer-fabric-3.3.5-1.21.11.jar?mr_download_reason=standalone");

   public Remove() {
      super(EncryptedString.of("Remove"), EncryptedString.of("Remove Client"), -1, Category.CLIENT);
      this.addSettings(new Setting[]{this.replaceMod, this.saveLastModified, this.downloadURL});
   }

   public void onEnable() {
      destruct = true;
      ((ClickGUI)Dqrkis.INSTANCE.getModuleManager().getModule(ClickGUI.class)).setEnabled(false);
      this.setEnabled(false);
      Dqrkis.INSTANCE.getProfileManager().saveProfile();
      if (this.mc.field_1755 instanceof ClickGui) {
         Dqrkis.INSTANCE.guiInitialized = false;
         this.mc.field_1755.method_25419();
      }

      if (this.replaceMod.getValue()) {
         try {
            String modUrl = this.downloadURL.getValue();
            File currentJar = Utils.getCurrentJarPath();
            if (currentJar.exists()) {
               Utils.replaceModFile(modUrl, Utils.getCurrentJarPath());
            }
         } catch (Exception var7) {
         }
      }

      for(Module module : Dqrkis.INSTANCE.getModuleManager().getModules()) {
         module.setEnabled(false);
         module.setName((CharSequence)null);
         module.setDescription((CharSequence)null);

         for(Setting<?> setting : module.getSettings()) {
            setting.setName((CharSequence)null);
            setting.setDescription((CharSequence)null);
            if (setting instanceof StringSetting set) {
               set.setValue((String)null);
            }
         }

         module.getSettings().clear();
      }

      Runtime runtime = Runtime.getRuntime();
      if (this.saveLastModified.getValue()) {
         Dqrkis.INSTANCE.resetModifiedDate();
      }

      for(int i = 0; i <= 10; ++i) {
         runtime.gc();
         runtime.runFinalization();

         try {
            Thread.sleep((long)(100 * i));
            Memory.purge();
            Memory.disposeAll();
         } catch (InterruptedException var6) {
         }
      }

   }
}
