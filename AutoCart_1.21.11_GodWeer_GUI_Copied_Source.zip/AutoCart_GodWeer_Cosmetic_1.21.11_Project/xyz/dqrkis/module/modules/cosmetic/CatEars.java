package xyz.dqrkis.module.modules.cosmetic;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.utils.EncryptedString;

/** Simple 3D cat-ear cosmetic adapted from GodWeer. */
public final class CatEars extends Module {
    public static final CatEars INSTANCE = new CatEars();
    private static final class_2960 WHITE = class_2960.method_60655("minecraft", "textures/misc/white.png");

    public CatEars() {
        super(EncryptedString.of("Cat Ears"), EncryptedString.of("3D cosmetic adapted from GodWeer"), -1, Category.CLIENT);
    }

    public boolean shouldRender(class_1297 entity) {
        if (!isEnabled() || !(entity instanceof class_1657)) return false;
        class_310 mc = class_310.method_1551();
        return entity == mc.field_1724 && !mc.field_1690.method_31044().method_31034();
    }

    public void render(class_4587 matrices, class_4597 vertexConsumers, int light) {
        // Rendering is handled by CatEarsFeatureRenderer.
    }
}
