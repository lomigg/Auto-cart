package xyz.dqrkis.module.modules.cosmetic;

/**
 * Optional renderer integration point for the Cat Ears cosmetic.
 *
 * Kept deliberately dependency-free until the actual 1.21.11 renderer hook is
 * implemented. This avoids stale/duplicate imports from older Minecraft
 * renderer APIs causing compilation failures.
 */
public final class CatEarsFeatureRenderer {
    private CatEarsFeatureRenderer() {
    }
}
