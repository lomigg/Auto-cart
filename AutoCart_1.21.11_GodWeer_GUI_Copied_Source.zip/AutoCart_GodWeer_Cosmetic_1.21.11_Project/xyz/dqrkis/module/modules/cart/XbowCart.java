package xyz.dqrkis.module.modules.cart;

import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3965;
import net.minecraft.class_7923;
import net.minecraft.class_239.class_240;
import org.lwjgl.glfw.GLFW;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.module.setting.Setting;
import xyz.dqrkis.utils.EncryptedString;
import xyz.dqrkis.utils.TimerUtils;

public final class XbowCart extends Module implements TickListener {
   private final NumberSetting railDelay = new NumberSetting(EncryptedString.of("Rail Delay"), (double)0.0F, (double)100.0F, (double)50.0F, (double)1.0F);
   private final NumberSetting tntDelay = new NumberSetting(EncryptedString.of("TNT Delay"), (double)0.0F, (double)100.0F, (double)50.0F, (double)1.0F);
   private final NumberSetting flintDelay = new NumberSetting(EncryptedString.of("Flint Delay"), (double)0.0F, (double)100.0F, (double)50.0F, (double)1.0F);
   private final NumberSetting crossbowDelay = new NumberSetting(EncryptedString.of("Crossbow Delay"), (double)0.0F, (double)100.0F, (double)50.0F, (double)1.0F);
   private final KeybindSetting macroKey = new KeybindSetting(EncryptedString.of("Key"), -1, false);
   private final TimerUtils timer = new TimerUtils();
   private boolean isRunning = false;
   private int currentStep = 0;

   public XbowCart() {
      super(EncryptedString.of("Xbow Cart"), EncryptedString.of("Automates rail, tnt minecart, flint & steel and crossbow sequence"), -1, Category.CART);
      this.addSettings(new Setting[]{this.railDelay, this.tntDelay, this.flintDelay, this.crossbowDelay, this.macroKey});
   }

   public void onEnable() {
      this.eventManager.add(TickListener.class, this);
      this.resetState();
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(TickListener.class, this);
      this.resetState();
      super.onDisable();
   }

   public void onTick() {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null && this.mc.field_1761 != null) {
         int key = this.macroKey.getKey();
         if (this.mc.field_1755 == null && key > 0 && GLFW.glfwGetKey(this.mc.method_22683().method_4490(), key) == 1) {
            this.triggerMacro();
         }

         if (this.isRunning) {
            long currentDelay = this.getCurrentStepDelay();
            if (this.timer.hasReached((double)currentDelay)) {
               this.executeStep(this.currentStep);
               ++this.currentStep;
               this.timer.reset();
               if (this.currentStep > 3) {
                  this.isRunning = false;
                  this.currentStep = 0;
               }
            }
         }

      }
   }

   public void triggerMacro() {
      if (!this.isRunning) {
         this.isRunning = true;
         this.currentStep = 0;
         this.timer.reset();
      }

   }

   private long getCurrentStepDelay() {
      long var10000;
      switch (this.currentStep) {
         case 0 -> var10000 = (long)this.railDelay.getValue();
         case 1 -> var10000 = (long)this.tntDelay.getValue();
         case 2 -> var10000 = (long)this.flintDelay.getValue();
         case 3 -> var10000 = (long)this.crossbowDelay.getValue();
         default -> var10000 = 50L;
      }

      return var10000;
   }

   private void executeStep(int step) {
      switch (step) {
         case 0 -> this.switchToAndUseItem("rail");
         case 1 -> this.switchToAndUseItem("tnt_minecart");
         case 2 -> this.switchToAndUseItem("flint_and_steel");
         case 3 -> this.switchToItem("crossbow");
      }

   }

   private boolean switchToItem(String query) {
      if (this.mc.field_1724 == null) {
         return false;
      } else {
         for(int i = 0; i < 9; ++i) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            if (this.matchesItem(stack, query)) {
               this.mc.field_1724.method_31548().method_61496(i);
               return true;
            }
         }

         return false;
      }
   }

   private void switchToAndUseItem(String query) {
      if (this.mc.field_1724 != null && this.mc.field_1761 != null && this.mc.field_1765 != null) {
         if (this.switchToItem(query) && this.mc.field_1765.method_17783() == class_240.field_1332) {
            class_3965 blockHit = (class_3965)this.mc.field_1765;
            this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, blockHit);
            this.mc.field_1724.method_6104(class_1268.field_5808);
         }

      }
   }

   private boolean matchesItem(class_1799 stack, String query) {
      if (stack != null && !stack.method_7960()) {
         class_2960 id = class_7923.field_41178.method_10221(stack.method_7909());
         String path = id.method_12832().toLowerCase();
         return path.contains(query.toLowerCase());
      } else {
         return false;
      }
   }

   private void resetState() {
      this.isRunning = false;
      this.currentStep = 0;
      this.timer.reset();
   }
}
