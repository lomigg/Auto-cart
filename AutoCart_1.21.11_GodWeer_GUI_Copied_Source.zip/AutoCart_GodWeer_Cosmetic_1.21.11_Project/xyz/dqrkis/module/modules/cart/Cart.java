package xyz.dqrkis.module.modules.cart;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2868;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_2350.class_2353;
import net.minecraft.class_239.class_240;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.module.setting.Setting;
import xyz.dqrkis.utils.EncryptedString;

public final class Cart extends Module implements TickListener {
   private final BooleanSetting placeDefense = new BooleanSetting(EncryptedString.of("Place Defense Block"), true);
   private final NumberSetting blockDelay = new NumberSetting(EncryptedString.of("Block Delay"), (double)0.0F, (double)10.0F, (double)0.0F, (double)1.0F);
   private boolean wasUsingBow = false;
   private int stage = 0;
   private int delayTimer = 0;
   private class_3965 initialHit;
   private class_2338 railPos;

   public Cart() {
      super(EncryptedString.of("Auto Cart"), EncryptedString.of("Cart By phucnguyen_ "), -1, Category.CART);
      this.addSettings(new Setting[]{this.placeDefense, this.blockDelay});
   }

   public void onEnable() {
      this.eventManager.add(TickListener.class, this);
      this.reset();
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(TickListener.class, this);
      this.reset();
      super.onDisable();
   }

   public void onTick() {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null && this.mc.method_1562() != null && this.mc.field_1761 != null) {
         boolean isUsingBow = this.mc.field_1724.method_6115() && this.mc.field_1724.method_6030().method_31574(class_1802.field_8102);
         if (this.wasUsingBow && !isUsingBow) {
            this.processTarget();
         }

         this.wasUsingBow = isUsingBow;
         switch (this.stage) {
            case 1:
               if (this.initialHit != null && !this.isRailPlaced(this.railPos)) {
                  int railSlot = this.findRailSlot();
                  if (railSlot != -1) {
                     this.switchToSlot(railSlot);
                     this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, this.initialHit);
                     this.mc.field_1724.method_6104(class_1268.field_5808);
                  }
               }

               this.stage = 2;
               break;
            case 2:
               int cartSlot = this.findTNTMinecartSlot();
               if (cartSlot != -1 && this.railPos != null) {
                  this.switchToSlot(cartSlot);
                  class_3965 hit = new class_3965(this.railPos.method_46558(), class_2350.field_11036, this.railPos, false);
                  this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, hit);
                  this.mc.field_1724.method_6104(class_1268.field_5808);
               }

               if (!this.placeDefense.getValue()) {
                  this.reset();
               } else {
                  this.stage = 3;
               }
               break;
            case 3:
               if (this.delayTimer < this.blockDelay.getValueInt()) {
                  ++this.delayTimer;
                  return;
               }

               int blockSlot = this.findDefenseBlockSlot();
               if (blockSlot != -1 && this.railPos != null) {
                  this.switchToSlot(blockSlot);
                  this.placeDefenseBlock();
               }

               this.reset();
         }

      }
   }

   private void processTarget() {
      if (this.mc.field_1765 != null) {
         if (this.mc.field_1765 instanceof class_3966) {
            this.reset();
         } else {
            class_239 var2 = this.mc.field_1765;
            if (var2 instanceof class_3965) {
               class_3965 hit = (class_3965)var2;
               if (hit.method_17783() == class_240.field_1332) {
                  class_2338 targetPos = hit.method_17777();
                  if (this.mc.field_1687.method_8320(targetPos).method_27852(class_2246.field_10343)) {
                     this.reset();
                     return;
                  }

                  if (this.isRailPlaced(targetPos)) {
                     this.railPos = targetPos;
                     this.initialHit = hit;
                     this.stage = 2;
                     return;
                  }

                  this.initialHit = hit;
                  this.railPos = targetPos.method_10093(hit.method_17780());
                  this.stage = 1;
               }
            }

         }
      }
   }

   private void placeDefenseBlock() {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null && this.mc.field_1761 != null && this.railPos != null) {
         class_243 playerPos = this.mc.field_1724.method_73189();
         class_243 center = this.railPos.method_46558();
         class_243 away = center.method_1020(playerPos).method_1029();
         double distance = playerPos.method_1022(center);
         class_2338 blockTarget = new class_2338((int)Math.floor(playerPos.field_1352 + away.field_1352 * Math.min(distance * 0.6, (double)3.0F)), this.railPos.method_10264(), (int)Math.floor(playerPos.field_1350 + away.field_1350 * Math.min(distance * 0.6, (double)3.0F)));
         if (blockTarget.equals(this.railPos)) {
            blockTarget = this.railPos.method_10069(-((int)Math.round(away.field_1352)), 0, -((int)Math.round(away.field_1350)));
         }

         class_2338 belowBlock = blockTarget.method_10074();
         boolean foundSupport = this.mc.field_1687.method_8320(belowBlock).method_26212(this.mc.field_1687, belowBlock);
         if (!foundSupport) {
            for(class_2350 direction : class_2353.field_11062) {
               class_2338 candidate = this.railPos.method_10093(direction);
               class_2338 candidateBelow = candidate.method_10074();
               if (this.mc.field_1687.method_8320(candidateBelow).method_26212(this.mc.field_1687, candidateBelow) && (this.mc.field_1687.method_8320(candidate).method_26215() || this.mc.field_1687.method_8320(candidate).method_45474())) {
                  belowBlock = candidateBelow;
                  foundSupport = true;
                  break;
               }
            }
         }

         if (foundSupport) {
            class_3965 hit = new class_3965(belowBlock.method_46558().method_1031((double)0.0F, (double)0.5F, (double)0.0F), class_2350.field_11036, belowBlock, false);
            class_1269 result = this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, hit);
            if (result.method_23665()) {
               this.mc.field_1724.method_6104(class_1268.field_5808);
            }
         }

      }
   }

   private void switchToSlot(int slot) {
      if (this.mc.field_1724 != null && this.mc.method_1562() != null) {
         if (this.mc.field_1724.method_31548().method_67532() != slot) {
            this.mc.field_1724.method_31548().method_61496(slot);
            this.mc.method_1562().method_52787(new class_2868(slot));
         }
      }
   }

   private void reset() {
      this.stage = 0;
      this.delayTimer = 0;
      this.initialHit = null;
      this.railPos = null;
   }

   private boolean isRailPlaced(class_2338 pos) {
      if (this.mc.field_1687 != null && pos != null) {
         class_2680 state = this.mc.field_1687.method_8320(pos);
         return state.method_27852(class_2246.field_10167) || state.method_27852(class_2246.field_10425) || state.method_27852(class_2246.field_10025) || state.method_27852(class_2246.field_10546);
      } else {
         return false;
      }
   }

   private int findTNTMinecartSlot() {
      if (this.mc.field_1724 == null) {
         return -1;
      } else {
         for(int i = 0; i < 9; ++i) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_31574(class_1802.field_8069)) {
               return i;
            }
         }

         return -1;
      }
   }

   private int findRailSlot() {
      if (this.mc.field_1724 == null) {
         return -1;
      } else {
         for(int i = 0; i < 9; ++i) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && (stack.method_31574(class_1802.field_8129) || stack.method_31574(class_1802.field_8848) || stack.method_31574(class_1802.field_8211) || stack.method_31574(class_1802.field_8655))) {
               return i;
            }
         }

         return -1;
      }
   }

   private int findDefenseBlockSlot() {
      if (this.mc.field_1724 == null) {
         return -1;
      } else {
         for(int i = 0; i < 9; ++i) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_31574(class_1802.field_8281)) {
               return i;
            }
         }

         for(int i = 0; i < 9; ++i) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960()) {
               String itemName = stack.method_7909().toString().toLowerCase();
               if (itemName.contains("log") || itemName.contains("wood") || itemName.contains("stem")) {
                  return i;
               }
            }
         }

         return -1;
      }
   }
}
