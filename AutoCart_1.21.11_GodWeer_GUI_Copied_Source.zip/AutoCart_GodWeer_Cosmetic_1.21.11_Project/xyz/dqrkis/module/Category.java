package xyz.dqrkis.module;

import xyz.dqrkis.utils.EncryptedString;

public enum Category {
   CART(EncryptedString.of("Cart PvP")),
   CLIENT(EncryptedString.of("Client"));

   public final CharSequence name;

   private Category(CharSequence name) {
      this.name = name;
   }

   // $FF: synthetic method
   private static Category[] $values() {
      return new Category[]{CART, CLIENT};
   }
}
