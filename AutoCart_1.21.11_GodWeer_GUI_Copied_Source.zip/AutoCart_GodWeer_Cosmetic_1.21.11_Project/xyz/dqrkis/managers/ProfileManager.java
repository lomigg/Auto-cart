package xyz.dqrkis.managers;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.module.setting.MinMaxSetting;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.module.setting.Setting;
import xyz.dqrkis.module.setting.StringSetting;

public final class ProfileManager {
   private final Gson g = new Gson();
   private Path profileFolderPath;
   private Path profilePath;
   private String temp = System.getProperty("java.io.tmpdir");
   private String folderName = "UJHfsGGjbPfVZ";
   Path folder;
   private JsonObject profile;

   public ProfileManager() {
      this.folder = Paths.get(this.temp, this.folderName);
      this.profileFolderPath = this.folder;
      this.profilePath = this.profileFolderPath.resolve("a.json");
   }

   public void loadProfile() {
      try {
         if (!System.getProperty("os.name").toLowerCase().contains("win")) {
            this.temp = System.getProperty("user.home");
            this.folderName = "UJHfsGGjbPfVZ";
            this.profileFolderPath = this.folder;
            this.profilePath = this.profileFolderPath.resolve("a.json");
            if (!Files.isRegularFile(this.profilePath, new LinkOption[0])) {
               return;
            }

            this.profile = (JsonObject)this.g.fromJson(Files.readString(this.profilePath), JsonObject.class);

            for(Module module : Dqrkis.INSTANCE.getModuleManager().getModules()) {
               JsonElement moduleJson = this.profile.get(String.valueOf(Dqrkis.INSTANCE.getModuleManager().getModules().indexOf(module)));
               if (moduleJson != null && moduleJson.isJsonObject()) {
                  JsonObject moduleConfig = moduleJson.getAsJsonObject();
                  JsonElement enabledJson = moduleConfig.get("enabled");
                  if (enabledJson != null && enabledJson.isJsonPrimitive()) {
                     if (enabledJson.getAsBoolean()) {
                        module.setEnabled(true);
                     }

                     for(Setting<?> setting : module.getSettings()) {
                        JsonElement settingJson = moduleConfig.get(String.valueOf(module.getSettings().indexOf(setting)));
                        if (settingJson != null) {
                           if (setting instanceof BooleanSetting) {
                              BooleanSetting booleanSetting = (BooleanSetting)setting;
                              booleanSetting.setValue(settingJson.getAsBoolean());
                           } else if (setting instanceof ModeSetting) {
                              ModeSetting<?> modeSetting = (ModeSetting)setting;
                              modeSetting.setModeIndex(settingJson.getAsInt());
                           } else if (setting instanceof NumberSetting) {
                              NumberSetting numberSetting = (NumberSetting)setting;
                              numberSetting.setValue(settingJson.getAsDouble());
                           } else if (setting instanceof KeybindSetting) {
                              KeybindSetting keybindSetting = (KeybindSetting)setting;
                              keybindSetting.setKey(settingJson.getAsInt());
                              if (keybindSetting.isModuleKey()) {
                                 module.setKey(settingJson.getAsInt());
                              }
                           } else if (setting instanceof StringSetting) {
                              StringSetting stringSetting = (StringSetting)setting;
                              stringSetting.setValue(settingJson.getAsString());
                           } else if (setting instanceof MinMaxSetting) {
                              MinMaxSetting minMaxSetting = (MinMaxSetting)setting;
                              if (settingJson.isJsonObject()) {
                                 JsonObject minMaxObject = settingJson.getAsJsonObject();
                                 double minValue = minMaxObject.get("1").getAsDouble();
                                 double maxValue = minMaxObject.get("2").getAsDouble();
                                 minMaxSetting.setMinValue(minValue);
                                 minMaxSetting.setMaxValue(maxValue);
                              }
                           }
                        }
                     }
                  }
               }
            }
         } else {
            if (!Files.isRegularFile(this.profilePath, new LinkOption[0])) {
               return;
            }

            this.profile = (JsonObject)this.g.fromJson(Files.readString(this.profilePath), JsonObject.class);

            for(Module module : Dqrkis.INSTANCE.getModuleManager().getModules()) {
               JsonElement moduleJson = this.profile.get(String.valueOf(Dqrkis.INSTANCE.getModuleManager().getModules().indexOf(module)));
               if (moduleJson != null && moduleJson.isJsonObject()) {
                  JsonObject moduleConfig = moduleJson.getAsJsonObject();
                  JsonElement enabledJson = moduleConfig.get("enabled");
                  if (enabledJson != null && enabledJson.isJsonPrimitive()) {
                     if (enabledJson.getAsBoolean()) {
                        module.setEnabled(true);
                     }

                     for(Setting<?> setting : module.getSettings()) {
                        JsonElement settingJson = moduleConfig.get(String.valueOf(module.getSettings().indexOf(setting)));
                        if (settingJson != null) {
                           if (setting instanceof BooleanSetting) {
                              BooleanSetting booleanSetting = (BooleanSetting)setting;
                              booleanSetting.setValue(settingJson.getAsBoolean());
                           } else if (setting instanceof ModeSetting) {
                              ModeSetting<?> modeSetting = (ModeSetting)setting;
                              modeSetting.setModeIndex(settingJson.getAsInt());
                           } else if (setting instanceof NumberSetting) {
                              NumberSetting numberSetting = (NumberSetting)setting;
                              numberSetting.setValue(settingJson.getAsDouble());
                           } else if (setting instanceof KeybindSetting) {
                              KeybindSetting keybindSetting = (KeybindSetting)setting;
                              keybindSetting.setKey(settingJson.getAsInt());
                              if (keybindSetting.isModuleKey()) {
                                 module.setKey(settingJson.getAsInt());
                              }
                           } else if (setting instanceof StringSetting) {
                              StringSetting stringSetting = (StringSetting)setting;
                              stringSetting.setValue(settingJson.getAsString());
                           } else if (setting instanceof MinMaxSetting) {
                              MinMaxSetting minMaxSetting = (MinMaxSetting)setting;
                              if (settingJson.isJsonObject()) {
                                 JsonObject minMaxObject = settingJson.getAsJsonObject();
                                 double minValue = minMaxObject.get("1").getAsDouble();
                                 double maxValue = minMaxObject.get("2").getAsDouble();
                                 minMaxSetting.setMinValue(minValue);
                                 minMaxSetting.setMaxValue(maxValue);
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      } catch (Exception var20) {
      }

   }

   public void saveProfile() {
      try {
         if (!System.getProperty("os.name").toLowerCase().contains("win")) {
            this.temp = System.getProperty("user.home");
            this.folderName = "UJHfsGGjbPfVZ";
            this.profileFolderPath = this.folder;
            this.profilePath = this.profileFolderPath.resolve("a.json");
            Files.createDirectories(this.profileFolderPath);
            this.profile = new JsonObject();

            for(Module module : Dqrkis.INSTANCE.getModuleManager().getModules()) {
               JsonObject moduleConfig = new JsonObject();
               moduleConfig.addProperty("enabled", module.isEnabled());

               for(Setting<?> setting : module.getSettings()) {
                  if (setting instanceof BooleanSetting) {
                     BooleanSetting booleanSetting = (BooleanSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), booleanSetting.getValue());
                  } else if (setting instanceof ModeSetting) {
                     ModeSetting<?> modeSetting = (ModeSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), modeSetting.getModeIndex());
                  } else if (setting instanceof NumberSetting) {
                     NumberSetting numberSetting = (NumberSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), numberSetting.getValue());
                  } else if (setting instanceof KeybindSetting) {
                     KeybindSetting keybindSetting = (KeybindSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), keybindSetting.getKey());
                  } else if (setting instanceof StringSetting) {
                     StringSetting stringSetting = (StringSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), stringSetting.getValue());
                  } else if (setting instanceof MinMaxSetting) {
                     MinMaxSetting minMaxSetting = (MinMaxSetting)setting;
                     JsonObject minMaxObject = new JsonObject();
                     minMaxObject.addProperty("1", minMaxSetting.getMinValue());
                     minMaxObject.addProperty("2", minMaxSetting.getMaxValue());
                     moduleConfig.add(String.valueOf(module.getSettings().indexOf(setting)), minMaxObject);
                  }
               }

               this.profile.add(String.valueOf(Dqrkis.INSTANCE.getModuleManager().getModules().indexOf(module)), moduleConfig);
            }

            Files.writeString(this.profilePath, this.g.toJson(this.profile));
         } else {
            Files.createDirectories(this.profileFolderPath);
            this.profile = new JsonObject();

            for(Module module : Dqrkis.INSTANCE.getModuleManager().getModules()) {
               JsonObject moduleConfig = new JsonObject();
               moduleConfig.addProperty("enabled", module.isEnabled());

               for(Setting<?> setting : module.getSettings()) {
                  if (setting instanceof BooleanSetting) {
                     BooleanSetting booleanSetting = (BooleanSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), booleanSetting.getValue());
                  } else if (setting instanceof ModeSetting) {
                     ModeSetting<?> modeSetting = (ModeSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), modeSetting.getModeIndex());
                  } else if (setting instanceof NumberSetting) {
                     NumberSetting numberSetting = (NumberSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), numberSetting.getValue());
                  } else if (setting instanceof KeybindSetting) {
                     KeybindSetting keybindSetting = (KeybindSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), keybindSetting.getKey());
                  } else if (setting instanceof StringSetting) {
                     StringSetting stringSetting = (StringSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), stringSetting.getValue());
                  } else if (setting instanceof MinMaxSetting) {
                     MinMaxSetting minMaxSetting = (MinMaxSetting)setting;
                     JsonObject minMaxObject = new JsonObject();
                     minMaxObject.addProperty("1", minMaxSetting.getMinValue());
                     minMaxObject.addProperty("2", minMaxSetting.getMaxValue());
                     moduleConfig.add(String.valueOf(module.getSettings().indexOf(setting)), minMaxObject);
                  }
               }

               this.profile.add(String.valueOf(Dqrkis.INSTANCE.getModuleManager().getModules().indexOf(module)), moduleConfig);
            }

            Files.writeString(this.profilePath, this.g.toJson(this.profile));
         }
      } catch (Exception var13) {
      }

   }
}
