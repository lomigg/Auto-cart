package xyz.dqrkis.managers;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_3966;
import xyz.dqrkis.Dqrkis;

public final class FriendManager {
   private final Set<String> friends = new HashSet();

   public void addFriend(class_1657 player) {
      this.friends.add(player.method_5477().getString());
   }

   public void removeFriend(class_1657 player) {
      this.friends.remove(player.method_5477().getString());
   }

   public boolean isFriend(class_1657 player) {
      return this.friends.contains(player.method_5477().getString());
   }

   public boolean isAimingOverFriend() {
      class_239 var2 = Dqrkis.mc.field_1765;
      if (var2 instanceof class_3966 hitResult) {
         class_1297 entity = hitResult.method_17782();
         if (entity instanceof class_1657 player) {
            return this.isFriend(player);
         }
      }

      return false;
   }
}
