# AutoCart + GodWeer Cosmetic — Minecraft 1.21.11

This is a reconstructed Fabric/Loom Gradle project from the supplied source archive.

## Build

Requirements:
- Java 21
- Gradle 8.14.x or newer compatible with Fabric Loom 1.14.10
- Internet access for Minecraft/Fabric dependencies

Run:

    gradle build

The installable/remapped mod jar is produced under:

    build/libs/

Use the regular non-`-dev` jar.

## Important

The supplied source uses Minecraft Intermediary names (`class_`, `method_`, `field_`).
The build intentionally does not declare Yarn mappings, so Loom compiles against Intermediary names.
The supplied CatEarsFeatureRenderer and PlayerEntityRendererMixin are placeholders; the CatEars
module is present, but the actual 3D renderer hook is not implemented in this archive.
